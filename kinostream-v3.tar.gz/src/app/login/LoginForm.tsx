"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import {
  phoneLoginAction,
  checkPhoneVerificationAction,
  type PhoneLoginState,
} from "@/lib/actions/account";

const initialState: PhoneLoginState = { stage: "phone" };
const POLL_INTERVAL_MS = 3000;

function useCountdown(expiresAt: string | undefined): number {
  const [secondsLeft, setSecondsLeft] = useState<number>(() =>
    expiresAt ? Math.max(0, Math.round((new Date(expiresAt).getTime() - Date.now()) / 1000)) : 0
  );

  useEffect(() => {
    if (!expiresAt) return;
    const tick = () =>
      setSecondsLeft(Math.max(0, Math.round((new Date(expiresAt).getTime() - Date.now()) / 1000)));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt]);

  return secondsLeft;
}

export default function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [state, formAction, pending] = useActionState(phoneLoginAction, initialState);
  const [pollError, setPollError] = useState<string | undefined>();
  const [expired, setExpired] = useState(false);
  const pollingRef = useRef(false);

  const stage = expired ? "phone" : state.stage;
  const secondsLeft = useCountdown(state.stage === "verify" ? state.expiresAt : undefined);

  // stage "verify" болмогц verify.mn session-ийн статусыг 3 секунд тутам шалгана.
  useEffect(() => {
    if (state.stage !== "verify" || !state.sessionId || !state.phone || expired) return;
    pollingRef.current = true;

    const sessionId = state.sessionId;
    const phone = state.phone;

    const poll = async () => {
      if (!pollingRef.current) return;
      try {
        const result = await checkPhoneVerificationAction(phone, sessionId, callbackUrl);
        if (!pollingRef.current) return;
        if (result.status === "expired") {
          setExpired(true);
          pollingRef.current = false;
        } else if (result.status === "error") {
          setPollError(result.error);
        } else {
          setPollError(undefined);
        }
      } catch {
        // NEXT_REDIRECT throw-г Next.js өөрөө барьж чиглүүлнэ — алдаа биш.
      }
    };

    const id = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      pollingRef.current = false;
      clearInterval(id);
    };
  }, [state.stage, state.sessionId, state.phone, callbackUrl, expired]);

  useEffect(() => {
    if (secondsLeft === 0 && state.stage === "verify") {
      setExpired(true);
    }
  }, [secondsLeft, state.stage]);

  if (stage === "verify" && state.sessionId) {
    return (
      <div className="card space-y-4 p-5">
        <div className="rounded-lg bg-accent/10 p-3 text-sm">
          <p className="whitespace-pre-line">{state.displayInstruction}</p>
        </div>

        {state.smsUri && (
          <a href={state.smsUri} className="btn-primary block w-full text-center">
            SMS илгээх (утсаараа)
          </a>
        )}

        <div className="flex items-center justify-between text-xs text-muted">
          <span>Хүлээж байна... (3 секунд тутам автоматаар шалгана)</span>
          <span>{Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, "0")}</span>
        </div>

        {pollError && <p className="text-sm text-accent-2">{pollError}</p>}

        <a href="/login" className="block text-center text-sm text-muted hover:underline">
          Өөр дугаар ашиглах
        </a>
      </div>
    );
  }

  return (
    <form action={formAction} className="card space-y-3 p-5">
      <input type="hidden" name="callbackUrl" value={callbackUrl} />

      <div>
        <label className="mb-1 block text-sm text-muted">Утасны дугаар</label>
        <input
          name="phone"
          type="tel"
          inputMode="numeric"
          autoComplete="tel"
          placeholder="99112233"
          required
          autoFocus
          className="input w-full"
        />
      </div>

      {expired && (
        <p className="text-sm text-accent-2">
          Баталгаажуулах хугацаа дууссан байна. Дугаараа дахин оруулж, шинэ код авна уу.
        </p>
      )}

      {state.error && !expired && <p className="text-sm text-accent-2">{state.error}</p>}

      <button type="submit" disabled={pending} className="btn-primary w-full">
        {pending ? "Түр хүлээнэ үү..." : "Нэвтрэх"}
      </button>
    </form>
  );
}
