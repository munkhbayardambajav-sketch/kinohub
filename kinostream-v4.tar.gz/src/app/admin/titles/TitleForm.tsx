"use client";

import { useState } from "react";
import type { Category, ContentType, MangaChapter, Title, User } from "@/lib/types";

type ActionFn = (formData: FormData) => void | Promise<void>;

export default function TitleForm({
  categories,
  creators,
  initial,
  action,
}: {
  categories: Category[];
  creators: User[];
  initial?: Title;
  action: ActionFn;
}) {
  const [type, setType] = useState<ContentType>(initial?.type || "movie");
  const [chapters, setChapters] = useState<MangaChapter[]>(initial?.chapters || []);

  function addChapter() {
    setChapters((prev) => [
      ...prev,
      { id: crypto.randomUUID(), number: prev.length + 1, title: "", images: [] },
    ]);
  }

  function updateChapter(id: string, patch: Partial<MangaChapter>) {
    setChapters((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }

  function removeChapter(id: string) {
    setChapters((prev) => prev.filter((c) => c.id !== id));
  }

  return (
    <form action={action} className="card space-y-4 p-5">
      {initial && <input type="hidden" name="id" value={initial.id} />}
      <input type="hidden" name="chaptersJson" value={JSON.stringify(chapters)} />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-muted">Төрөл</label>
          <select
            name="type"
            value={type}
            onChange={(e) => setType(e.target.value as ContentType)}
            className="input w-full"
          >
            <option value="movie">Кино</option>
            <option value="manga">Манга</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm text-muted">Огноо (жил)</label>
          <input name="year" type="number" defaultValue={initial?.year} className="input w-full" />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Гарчиг</label>
        <input name="title" required defaultValue={initial?.title} className="input w-full" />
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Тайлбар</label>
        <textarea
          name="description"
          required
          rows={4}
          defaultValue={initial?.description}
          className="input w-full"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-muted">Постер зургийн URL</label>
          <input name="poster" required defaultValue={initial?.poster} className="input w-full" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-muted">Ар зургийн URL (заавал биш)</label>
          <input name="backdrop" defaultValue={initial?.backdrop} className="input w-full" />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Улс (заавал биш)</label>
        <input name="country" defaultValue={initial?.country} className="input w-full" />
      </div>

      <div>
        <label className="mb-2 block text-sm text-muted">Ангилал</label>
        <div className="flex flex-wrap gap-3 text-sm">
          {categories.map((c) => (
            <label key={c.id} className="flex items-center gap-1.5">
              <input
                type="checkbox"
                name="categoryIds"
                value={c.id}
                defaultChecked={initial?.categoryIds.includes(c.id)}
              />
              {c.name}
            </label>
          ))}
        </div>
      </div>

      <div className="flex gap-6 text-sm">
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="featured" defaultChecked={initial?.featured} />
          Онцлох
        </label>
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="ageRestricted" defaultChecked={initial?.ageRestricted} />
          18+
        </label>
      </div>

      <div className="rounded border border-border p-3">
        <p className="mb-2 text-sm font-semibold text-muted">Төлбөр / Нийлүүлэгч</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm text-muted">
              Үнэ (₮) — хоосон/0 бол үнэгүй
            </label>
            <input
              name="price"
              type="number"
              min={0}
              step={100}
              defaultValue={initial?.price}
              className="input w-full"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm text-muted">Нийлүүлэгч (эзэмшигч)</label>
            <select name="creatorId" defaultValue={initial?.creatorId || ""} className="input w-full">
              <option value="">— Манай платформын контент —</option>
              {creators.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.email ?? c.phone ?? "—"})
                </option>
              ))}
            </select>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted">
          Үнэтэй бол тухайн нийлүүлэгч /creator дотор энэ контентын үзэлт, орлого, санхүүгийн
          тайлангаа харна. Хуваарилалт: манай компани 40%, нийлүүлэгч 60% (НӨАТ хассаны дараа).
        </p>
      </div>

      {type === "movie" ? (
        <div>
          <label className="mb-1 block text-sm text-muted">Видео URL (mp4 линк)</label>
          <input name="videoUrl" defaultValue={initial?.videoUrl} className="input w-full" />
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm text-muted">Бүлгүүд (манга)</label>
            <button type="button" onClick={addChapter} className="btn-secondary text-xs">
              + Бүлэг нэмэх
            </button>
          </div>
          {chapters.map((c) => (
            <div key={c.id} className="rounded border border-border p-3">
              <div className="mb-2 flex items-center gap-2">
                <input
                  type="number"
                  value={c.number}
                  onChange={(e) => updateChapter(c.id, { number: Number(e.target.value) })}
                  className="input w-20"
                />
                <input
                  value={c.title}
                  onChange={(e) => updateChapter(c.id, { title: e.target.value })}
                  placeholder="Бүлгийн нэр"
                  className="input flex-1"
                />
                <button
                  type="button"
                  onClick={() => removeChapter(c.id)}
                  className="btn-secondary text-xs text-accent-2"
                >
                  Устгах
                </button>
              </div>
              <textarea
                placeholder="Хуудасны зургийн URL (мөр бүрт нэг)"
                defaultValue={c.images.join("\n")}
                onChange={(e) =>
                  updateChapter(c.id, {
                    images: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean),
                  })
                }
                rows={3}
                className="input w-full text-xs"
              />
            </div>
          ))}
        </div>
      )}

      <button type="submit" className="btn-primary">
        Хадгалах
      </button>
    </form>
  );
}
