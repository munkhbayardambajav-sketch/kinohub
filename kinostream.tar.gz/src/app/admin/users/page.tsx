import { auth } from "@/auth";
import { listUsers } from "@/lib/repo";
import { deleteUserAction, toggleBanAction } from "@/lib/actions/admin";
import RoleSelect from "./RoleSelect";
import CreateUserForm from "./CreateUserForm";

const roleLabel: Record<string, string> = {
  admin: "Админ",
  creator: "Нийлүүлэгч",
  user: "Хэрэглэгч",
};

export default async function AdminUsersPage() {
  const [session, users] = await Promise.all([auth(), listUsers()]);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Хэрэглэгчид</h1>

      <div>
        <p className="mb-2 text-sm text-muted">
          Шинэ хэрэглэгч (жишээ нь: кино нийлүүлэгч) гараар үүсгэх:
        </p>
        <CreateUserForm />
      </div>

      <div className="card divide-y divide-border">
        {users.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center gap-3 p-3">
            <div className="flex-1">
              <p className="font-medium">
                {u.name} {u.id === session?.user?.id && <span className="text-xs text-muted">(та)</span>}
              </p>
              <p className="text-xs text-muted">{u.email}</p>
            </div>
            <span className="rounded bg-surface-2 px-2 py-0.5 text-xs">
              {roleLabel[u.role] ?? u.role}
            </span>
            {u.banned && (
              <span className="rounded bg-accent-2/20 px-2 py-0.5 text-xs text-accent-2">Хориглосон</span>
            )}

            <RoleSelect userId={u.id} role={u.role} disabled={u.id === session?.user?.id} />

            <form action={toggleBanAction}>
              <input type="hidden" name="id" value={u.id} />
              <input type="hidden" name="banned" value={String(!u.banned)} />
              <button type="submit" className="btn-secondary text-xs">
                {u.banned ? "Хориг цуцлах" : "Хориглох"}
              </button>
            </form>

            <form action={deleteUserAction}>
              <input type="hidden" name="id" value={u.id} />
              <button
                type="submit"
                className="btn-secondary text-xs text-accent-2"
                disabled={u.id === session?.user?.id}
              >
                Устгах
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}
