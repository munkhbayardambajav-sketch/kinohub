import { listAllPurchases, listTitles, listUsers } from "@/lib/repo";
import { createManualPurchaseAction } from "@/lib/actions/admin";
import { formatMnt } from "@/lib/finance";

export default async function AdminPurchasesPage() {
  const [purchases, titles, users] = await Promise.all([
    listAllPurchases(),
    listTitles(),
    listUsers(),
  ]);

  const titleById = new Map(titles.map((t) => [t.id, t]));
  const userById = new Map(users.map((u) => [u.id, u]));
  const pricedTitles = titles.filter((t) => t.price);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Худалдан авалт</h1>

      <div>
        <p className="mb-2 text-sm text-muted">
          Бэлнээр/бусад аргаар (QPay-гүйгээр) хийсэн худалдан авалтыг гараар бүртгэх:
        </p>
        <form action={createManualPurchaseAction} className="card grid grid-cols-1 gap-3 p-4 sm:grid-cols-3">
          <select name="userId" required className="input">
            <option value="">Хэрэглэгч сонгох...</option>
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.email})
              </option>
            ))}
          </select>
          <select name="titleId" required className="input">
            <option value="">Үнэтэй контент сонгох...</option>
            {pricedTitles.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} — {formatMnt(t.price!)}₮
              </option>
            ))}
          </select>
          <button type="submit" className="btn-primary">
            Худалдан авалт бүртгэх
          </button>
        </form>
        {pricedTitles.length === 0 && (
          <p className="mt-2 text-xs text-muted">
            Одоогоор үнэтэй контент алга — эхлээд Контент хэсэгт үнэ өгнө үү.
          </p>
        )}
      </div>

      <div className="card divide-y divide-border">
        {purchases.map((p) => {
          const title = titleById.get(p.titleId);
          const user = userById.get(p.userId);
          return (
            <div key={p.id} className="flex flex-wrap items-center gap-3 p-3 text-sm">
              <div className="flex-1">
                <p className="font-medium">{title?.title || "Устгагдсан контент"}</p>
                <p className="text-xs text-muted">
                  {user?.name || "?"} · {new Date(p.createdAt).toLocaleString("mn-MN")} ·{" "}
                  {p.method === "manual" ? "Гар аргаар" : "QPay"}
                </p>
              </div>
              <span className="text-xs text-muted">{formatMnt(p.amount)}₮</span>
              <span
                className={`rounded px-2 py-0.5 text-xs ${
                  p.status === "paid"
                    ? "bg-accent/20 text-accent"
                    : p.status === "pending"
                      ? "bg-surface-2 text-muted"
                      : "bg-accent-2/20 text-accent-2"
                }`}
              >
                {p.status === "paid" ? "Төлөгдсөн" : p.status === "pending" ? "Хүлээгдэж буй" : "Амжилтгүй"}
              </span>
            </div>
          );
        })}
        {purchases.length === 0 && <p className="p-4 text-muted">Худалдан авалт алга байна.</p>}
      </div>
    </div>
  );
}
