import LoginForm from "./LoginForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>;
}) {
  const { callbackUrl } = await searchParams;

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Нэвтрэх</h1>
      <LoginForm callbackUrl={callbackUrl || "/"} />
      <p className="mt-4 text-sm text-muted">
        Хаяг байхгүй юу?{" "}
        <a href="/register" className="text-accent hover:underline">
          Бүртгүүлэх
        </a>
      </p>
    </div>
  );
}
