"use server";

import { redirect } from "next/navigation";
import { AuthError } from "next-auth";
import { signIn } from "@/auth";
import { createUser } from "@/lib/repo";

export async function registerAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  if (!name || !email || !password) {
    return { error: "Бүх талбарыг бөглөнө үү." };
  }
  if (password.length < 6) {
    return { error: "Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой." };
  }

  try {
    await createUser({ name, email, password, role: "user" });
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Алдаа гарлаа." };
  }

  try {
    await signIn("credentials", { email, password, redirectTo: "/" });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Бүртгэл үүслээ, гэхдээ автоматаар нэвтрэхэд алдаа гарлаа. Дахин нэвтэрнэ үү." };
    }
    throw e;
  }

  redirect("/");
}

export async function loginAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const callbackUrl = String(formData.get("callbackUrl") || "/");

  try {
    await signIn("credentials", { email, password, redirectTo: callbackUrl });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Имэйл эсвэл нууц үг буруу байна." };
    }
    throw e;
  }

  return {};
}
