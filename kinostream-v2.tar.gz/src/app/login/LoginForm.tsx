"use client";

import { useActionState } from "react";
import { phoneLoginAction, type PhoneLoginState } from "@/lib/actions/account";

const initialState: PhoneLoginState = { stage: "phone" };

export default function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [state, formAction, pending] = useActionState(phoneLoginAction, initialState);
  const stage = state.stage;

  return (
    <form action={formAction} className="card space-y-3 p-5">
      <input type="hidden" name="callbackUrl" value={callbackUrl} />

      {stage === "phone" && (
        <div>
          <label className="mb-1 block text-sm text-muted">Утасны дугаар</label>
          <input
            name="phone"
            type="tel"
            inputMode="numeric"
            autoComplete="tel"
            placeholder="99112233"
            required
            autoFocus
            className="input w-full"
          />
        </div>
      )}

      {stage === "code" && (
        <>
          <input type="hidden" name="phone" value={state.phone} />
          <div className="rounded-lg bg-accent/10 p-3 text-sm">
            <p className="mb-1">
              Баталгаажуулах код:{" "}
              <span className="text-lg font-bold tracking-widest">{state.demoCode}</span>
            </p>
            <p className="text-muted">
              Энэ кодыг <span className="font-semibold">{state.specialNumber}</span> тусгай
              дугаарт мессежээр илгээж баталгаажуулна.
            </p>
            {state.info && <p className="mt-1 text-xs text-muted">{state.info}</p>}
          </div>
          <div>
            <label className="mb-1 block text-sm text-muted">Баталгаажуулах код</label>
            <input
              name="code"
              type="text"
              inputMode="numeric"
              maxLength={4}
              required
              autoFocus
              className="input w-full"
            />
          </div>
        </>
      )}

      {state.error && <p className="text-sm text-accent-2">{state.error}</p>}

      <button type="submit" disabled={pending} className="btn-primary w-full">
        {pending ? "Түр хүлээнэ үү..." : stage === "code" ? "Баталгаажуулах" : "Нэвтрэх"}
      </button>
    </form>
  );
}
