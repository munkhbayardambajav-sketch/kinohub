import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { authConfig } from "@/auth.config";
import { verifyOtp } from "@/lib/otp";

export const { handlers, signIn, signOut, auth } = NextAuth({
  ...authConfig,
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Имэйл", type: "email" },
        password: { label: "Нууц үг", type: "password" },
      },
      authorize: async (credentials) => {
        const email = (credentials?.email as string | undefined)?.toLowerCase().trim();
        const password = credentials?.password as string | undefined;
        if (!email || !password) return null;

        const db = await getDb();
        const user = db.data.users.find((u) => u.email?.toLowerCase() === email);
        if (!user || !user.passwordHash) return null;
        if (user.banned) return null;

        const valid = bcrypt.compareSync(password, user.passwordHash);
        if (!valid) return null;

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
    // Утасны дугаараар нэвтрэх/бүртгүүлэх урсгал:
    //  - Анхны удаа тухайн дугаараар нэвтрэх үед аккаунт автоматаар үүсэж,
    //    нэн даруй нэвтэрдэг (энэ кэйсд OTP-г сервер дотроо шууд шалгаж дамждаг).
    //  - Дараагийн удаа нэвтрэх бүрд 4 оронтой баталгаажуулах код шаардана.
    //    (Жинхэнэ SMS gateway хараахан холбогдоогүй тул кодыг сайт дээр нь
    //    түр харуулж, дахин оруулуулж баталгаажуулдаг демо горимоор ажиллана.)
    Credentials({
      id: "phone",
      name: "Утасны дугаар",
      credentials: {
        phone: { label: "Утасны дугаар", type: "text" },
        code: { label: "Баталгаажуулах код", type: "text" },
      },
      authorize: async (credentials) => {
        const phone = (credentials?.phone as string | undefined)?.trim();
        const code = (credentials?.code as string | undefined)?.trim();
        if (!phone || !code) return null;

        const db = await getDb();
        const user = db.data.users.find((u) => u.phone === phone);
        if (!user) return null;
        if (user.banned) return null;

        const ok = verifyOtp(phone, code);
        if (!ok) return null;

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
  ],
});
