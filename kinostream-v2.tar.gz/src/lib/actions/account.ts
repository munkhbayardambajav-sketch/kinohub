"use server";

import { redirect } from "next/navigation";
import { AuthError } from "next-auth";
import { signIn } from "@/auth";
import { createUser, createUserByPhone, getUserByPhone } from "@/lib/repo";
import { generateOtp } from "@/lib/otp";

export async function registerAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  if (!name || !email || !password) {
    return { error: "Бүх талбарыг бөглөнө үү." };
  }
  if (password.length < 6) {
    return { error: "Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой." };
  }

  try {
    await createUser({ name, email, password, role: "user" });
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Алдаа гарлаа." };
  }

  try {
    await signIn("credentials", { email, password, redirectTo: "/" });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Бүртгэл үүслээ, гэхдээ автоматаар нэвтрэхэд алдаа гарлаа. Дахин нэвтэрнэ үү." };
    }
    throw e;
  }

  redirect("/");
}

export async function loginAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const callbackUrl = String(formData.get("callbackUrl") || "/");

  try {
    await signIn("credentials", { email, password, redirectTo: callbackUrl });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Имэйл эсвэл нууц үг буруу байна." };
    }
    throw e;
  }

  return {};
}

// ---------------------------------------------------------------------------
// Утасны дугаараар нэвтрэх (анхны удаа автоматаар бүртгэл үүсгэж нэвтэрдэг,
// дараагийн удаа бүрд 4 оронтой код баталгаажуулдаг демо урсгал).
// ---------------------------------------------------------------------------

export type PhoneLoginState = {
  stage: "phone" | "code";
  phone?: string;
  demoCode?: string;
  specialNumber?: string;
  info?: string;
  error?: string;
};

const SPECIAL_NUMBER = "1552"; // демо/түр placeholder дугаар (жинхэнэ SMS gateway холбогдоогүй)

function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 11 && digits.startsWith("976")) return digits.slice(3);
  return digits;
}

export async function phoneLoginAction(
  _prevState: PhoneLoginState | undefined,
  formData: FormData
): Promise<PhoneLoginState> {
  const phone = normalizePhone(String(formData.get("phone") || ""));
  const code = String(formData.get("code") || "").trim();
  const callbackUrl = String(formData.get("callbackUrl") || "/");

  if (!/^\d{8}$/.test(phone)) {
    return { stage: "phone", error: "Утасны дугаараа 8 оронтой тоогоор зөв оруулна уу." };
  }

  // Stage 2: хэрэглэгч кодоо оруулж ирсэн бол баталгаажуулна.
  if (code) {
    try {
      await signIn("phone", { phone, code, redirectTo: callbackUrl });
    } catch (e) {
      if (e instanceof AuthError) {
        const demoCode = generateOtp(phone);
        return {
          stage: "code",
          phone,
          demoCode,
          specialNumber: SPECIAL_NUMBER,
          error: "Код буруу эсвэл хугацаа дууссан байна. Шинэ код илгээв, дахин оруулна уу.",
        };
      }
      throw e;
    }
    return { stage: "code", phone };
  }

  // Stage 1: зөвхөн утасны дугаар ирсэн.
  const existing = await getUserByPhone(phone);

  if (existing?.banned) {
    return { stage: "phone", error: "Энэ дугаар хориглогдсон байна." };
  }

  if (!existing) {
    // Анхны удаа: аккаунт үүсгээд шууд нэвтрүүлнэ (код харуулахгүй).
    await createUserByPhone(phone);
    const bootstrapCode = generateOtp(phone, 60_000);
    try {
      await signIn("phone", { phone, code: bootstrapCode, redirectTo: callbackUrl });
    } catch (e) {
      if (e instanceof AuthError) {
        return { stage: "phone", error: "Нэвтрэхэд алдаа гарлаа. Дахин оролдоно уу." };
      }
      throw e;
    }
    return { stage: "phone" };
  }

  // Дараагийн удаа: код харуулж баталгаажуулна (демо горим — жинхэнэ SMS
  // gateway холбогдоогүй тул кодыг энд шууд харуулж байна).
  const demoCode = generateOtp(phone);
  return {
    stage: "code",
    phone,
    demoCode,
    specialNumber: SPECIAL_NUMBER,
    info: "SMS үйлчилгээ хараахан холбогдоогүй тул кодыг түр зуур эндээс харж, доор оруулна уу.",
  };
}
