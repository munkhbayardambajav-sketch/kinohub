#!/usr/bin/env bash
# Нэг товчоор (эсвэл "./start.sh" гэж ажиллуулаад) сайтыг локал компьютер дээр
# суулгаж, тохируулаад, ажиллуулна. macOS болон Linux дээр зориулагдсан
# (Windows дээр start.bat-г ашиглана уу).
set -euo pipefail
cd "$(dirname "$0")"

echo "== MediaHub — локал тест орчин бэлдэж байна =="

# 1) Node.js шалгах
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "АЛДАА: Node.js суусан олдсонгүй."
  echo "Эхлээд https://nodejs.org хаягаас Node.js 20 буюу түүнээс дээш хувилбарыг суулгаад дахин ажиллуулна уу."
  exit 1
fi

NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])")
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo ""
  echo "АНХААРУУЛГА: Node.js $(node -v) хуучин байна (20+ санал болгож байна). Ажиллах магадлалтай ч асуудал гарвал шинэчилнэ үү."
fi

# 2) Сангуудыг суулгах (зөвхөн анх удаа буюу package.json өөрчлөгдсөн үед)
if [ ! -d node_modules ]; then
  echo ""
  echo "-- Шаардлагатай сангуудыг суулгаж байна (npm install)... энэ хэсэг хэдэн минут үргэлжилж болно --"
  npm install
fi

# 3) .env.local үүсгэх (байхгүй бол л)
if [ ! -f .env.local ]; then
  echo ""
  echo "-- .env.local үүсгэж, нууц түлхүүр (AUTH_SECRET) автоматаар үүсгэж байна --"
  cp .env.example .env.local
  SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64'))")
  # macOS (BSD sed) болон Linux (GNU sed) хоёуланд ажиллах хэлбэрээр солино
  if sed --version >/dev/null 2>&1; then
    sed -i "s|^AUTH_SECRET=.*|AUTH_SECRET=${SECRET}|" .env.local
  else
    sed -i '' "s|^AUTH_SECRET=.*|AUTH_SECRET=${SECRET}|" .env.local
  fi
fi

echo ""
echo "======================================================================"
echo " Бэлэн боллоо! Хэдэн секундийн дараа http://localhost:3000 нээгдэнэ."
echo ""
echo " Жишээ бүртгэлүүд:"
echo "   Админ:       admin@example.com     / ChangeMe123!"
echo "   Нийлүүлэгч:  creator@example.com   / password123"
echo "   Хэрэглэгч:   user@example.com      / password123"
echo ""
echo " Алхам алхмаар туршихыг хүсвэл TESTING.md файлыг нээж үзнэ үү."
echo " Зогсоохын тулд энэ цонхонд Ctrl+C дарна уу."
echo "======================================================================"
echo ""

# 4) Боломжтой бол хөтчийг автоматаар нээх (2 секунд хүлээгээд, дэвсэн процессоор)
(
  sleep 2
  if command -v open >/dev/null 2>&1; then
    open "http://localhost:3000" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:3000" >/dev/null 2>&1 || true
  fi
) &

# 5) Серверийг ажиллуулах (энэ мөр Ctrl+C дартал үргэлжилнэ)
npm run dev
