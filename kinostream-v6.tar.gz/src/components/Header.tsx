import Link from "next/link";
import { auth, signOut } from "@/auth";
import { SITE } from "@/lib/site";
import SearchBox from "./SearchBox";

export default async function Header() {
  const session = await auth();

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent font-bold text-[#14110a]">
            {SITE.name.charAt(0)}
          </span>
          <span className="text-lg font-bold tracking-tight">{SITE.name}</span>
        </Link>

        <nav className="hidden items-center gap-4 text-sm text-muted md:flex">
          <Link href="/browse/movie" className="hover:text-foreground">
            Кино
          </Link>
          <Link href="/browse/manga" className="hover:text-foreground">
            Манга
          </Link>
        </nav>

        <div className="ml-auto flex flex-1 items-center justify-end gap-3">
          <SearchBox />

          {session?.user ? (
            <div className="flex items-center gap-2">
              {session.user.role === "admin" && (
                <Link href="/admin" className="btn-secondary text-sm">
                  Админ панел
                </Link>
              )}
              {session.user.role === "creator" && (
                <Link href="/creator/reports" className="btn-secondary text-sm">
                  Нийлүүлэгчийн самбар
                </Link>
              )}
              <span className="hidden text-sm text-muted sm:inline">
                {session.user.name}
              </span>
              <form
                action={async () => {
                  "use server";
                  await signOut({ redirectTo: "/" });
                }}
              >
                <button type="submit" className="btn-secondary text-sm">
                  Гарах
                </button>
              </form>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className="btn-primary text-sm">
                Нэвтрэх
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
