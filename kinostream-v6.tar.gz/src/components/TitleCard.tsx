import Link from "next/link";
import type { Title } from "@/lib/types";
import { formatMnt } from "@/lib/finance";

export default function TitleCard({ title }: { title: Title }) {
  return (
    <Link href={`/title/${title.slug}`} className="group block">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={title.poster} alt={title.title} className="poster" loading="lazy" />
      <div className="mt-2">
        <p className="line-clamp-2 text-sm font-medium group-hover:text-accent">
          {title.title}
        </p>
        <div className="mt-1 flex items-center gap-2 text-xs text-muted">
          <span className="rounded bg-surface-2 px-1.5 py-0.5">
            {title.type === "movie" ? "Кино" : "Манга"}
          </span>
          {title.year && <span>{title.year}</span>}
          {title.ageRestricted && (
            <span className="rounded bg-accent-2/20 px-1.5 py-0.5 text-accent-2">18+</span>
          )}
          {!!title.price && (
            <span className="rounded bg-accent/20 px-1.5 py-0.5 text-accent">
              {formatMnt(title.price)}₮
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
