import type { CreatorReport, CreatorReportLine } from "@/lib/repo";
import { formatMnt, sumFinance } from "@/lib/finance";
import { PLATFORM_CUT_RATE, CREATOR_CUT_RATE } from "@/lib/finance";

const typeLabel: Record<CreatorReportLine["type"], string> = {
  movie: "Кино",
  manga: "Манга",
};

function Section({ type, lines }: { type: CreatorReportLine["type"]; lines: CreatorReportLine[] }) {
  const total = sumFinance(lines);
  return (
    <div className="mb-6">
      <h3 className="mb-2 text-sm font-semibold text-muted">{typeLabel[type]}</h3>
      <div className="overflow-x-auto rounded border border-border">
        <table className="w-full min-w-[900px] text-sm">
          <thead>
            <tr className="bg-surface-2 text-left text-xs text-muted">
              <th className="p-2">#</th>
              <th className="p-2">Контентийн нэр</th>
              <th className="p-2 text-right">Үнэ</th>
              <th className="p-2 text-right">Худалдсан тоо</th>
              <th className="p-2 text-right">Нийт орлого</th>
              <th className="p-2 text-right">НӨАТ</th>
              <th className="p-2 text-right">Ашиг</th>
              <th className="p-2 text-right">Апп шимтгэл</th>
              <th className="p-2 text-right">Хуваарилах дүн (НӨАТ-гүй)</th>
            </tr>
          </thead>
          <tbody>
            {lines.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-3 text-muted">
                  Мэдээлэл байхгүй
                </td>
              </tr>
            ) : (
              lines.map((l, i) => (
                <tr key={l.titleId} className="border-t border-border">
                  <td className="p-2 text-muted">{i + 1}</td>
                  <td className="p-2">{l.titleName}</td>
                  <td className="p-2 text-right">{formatMnt(l.price)}</td>
                  <td className="p-2 text-right">{l.salesCount}</td>
                  <td className="p-2 text-right">{formatMnt(l.grossRevenue)}</td>
                  <td className="p-2 text-right">{formatMnt(l.vat)}</td>
                  <td className="p-2 text-right">{formatMnt(l.profitAfterVat)}</td>
                  <td className="p-2 text-right">{formatMnt(l.platformCut)}</td>
                  <td className="p-2 text-right font-semibold text-accent">
                    {formatMnt(l.creatorCut)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {lines.length > 0 && (
            <tfoot>
              <tr className="border-t border-border font-semibold">
                <td className="p-2" colSpan={3}>
                  Нийт
                </td>
                <td className="p-2 text-right">
                  {lines.reduce((s, l) => s + l.salesCount, 0)}
                </td>
                <td className="p-2 text-right">{formatMnt(total.grossRevenue)}</td>
                <td className="p-2 text-right">{formatMnt(total.vat)}</td>
                <td className="p-2 text-right">{formatMnt(total.profitAfterVat)}</td>
                <td className="p-2 text-right">{formatMnt(total.platformCut)}</td>
                <td className="p-2 text-right text-accent">{formatMnt(total.creatorCut)}</td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default function FinanceReportTable({ report }: { report: CreatorReport }) {
  const movieLines = report.lines.filter((l) => l.type === "movie");
  const mangaLines = report.lines.filter((l) => l.type === "manga");

  return (
    <div>
      <Section type="movie" lines={movieLines} />
      <Section type="manga" lines={mangaLines} />

      <div className="card grid grid-cols-2 gap-4 p-4 sm:grid-cols-5">
        <Stat label="Нийт орлого" value={formatMnt(report.total.grossRevenue)} />
        <Stat label="НӨАТ" value={formatMnt(report.total.vat)} />
        <Stat label="Ашиг" value={formatMnt(report.total.profitAfterVat)} />
        <Stat
          label={`Апп шимтгэл (${Math.round(PLATFORM_CUT_RATE * 100)}%)`}
          value={formatMnt(report.total.platformCut)}
        />
        <Stat
          label={`Хуваарилах дүн (${Math.round(CREATOR_CUT_RATE * 100)}%)`}
          value={formatMnt(report.total.creatorCut)}
          highlight
        />
      </div>
    </div>
  );
}

function Stat({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className={`text-xl font-bold ${highlight ? "text-accent" : ""}`}>{value}₮</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}
