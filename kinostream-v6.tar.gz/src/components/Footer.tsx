import { SITE } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-border py-8 text-sm text-muted">
      <div className="mx-auto max-w-7xl px-4">
        <p>
          © {new Date().getFullYear()} {SITE.name}. Бүх контент нь жишээ/плейсхолдер
          өгөгдөл болно — өөрийн лицензтэй агуулгаараа сольж ашиглана уу.
        </p>
      </div>
    </footer>
  );
}
