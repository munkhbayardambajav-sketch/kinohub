import NextAuth from "next-auth";
import { authConfig } from "@/auth.config";

// Edge-safe: only decodes the JWT cookie and runs the `authorized` callback
// from auth.config.ts (no bcrypt/fs deps get pulled into this bundle).
const { auth } = NextAuth(authConfig);

export const proxy = auth;

export const config = {
  matcher: ["/admin/:path*", "/creator/:path*"],
};
