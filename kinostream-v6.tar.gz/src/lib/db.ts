import path from "node:path";
import fs from "node:fs";
import { JSONFilePreset } from "lowdb/node";
import type { Low } from "lowdb";
import { nanoid } from "nanoid";
import bcrypt from "bcryptjs";
import type { DbSchema, User, Category, Title, Purchase } from "./types";
import { computeFinance } from "./finance";

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "db.json");

const defaultData: DbSchema = {
  users: [],
  categories: [],
  titles: [],
  comments: [],
  ratings: [],
  purchases: [],
};

declare global {
   
  var __kinostream_db__: Promise<Low<DbSchema>> | undefined;
}

async function createDb(): Promise<Low<DbSchema>> {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  const db = await JSONFilePreset<DbSchema>(DATA_FILE, defaultData);
  await db.read();

  // Seed on first run
  if (db.data.users.length === 0 && db.data.titles.length === 0) {
    await seed(db);
  }

  // Migration: older data/db.json files (created before the creator/payments
  // feature) won't have a `purchases` array yet — backfill it in place.
  if (!Array.isArray(db.data.purchases)) {
    db.data.purchases = [];
    await db.write();
  }

  return db;
}

export function getDb(): Promise<Low<DbSchema>> {
  if (!globalThis.__kinostream_db__) {
    globalThis.__kinostream_db__ = createDb();
  }
  return globalThis.__kinostream_db__;
}

async function seed(db: Low<DbSchema>) {
  const now = new Date().toISOString();

  const adminPassword = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";
  const admin: User = {
    id: nanoid(),
    name: "Admin",
    email: process.env.SEED_ADMIN_EMAIL || "admin@example.com",
    passwordHash: bcrypt.hashSync(adminPassword, 10),
    role: "admin",
    createdAt: now,
  };

  const demoUser: User = {
    id: nanoid(),
    name: "Demo User",
    email: "user@example.com",
    passwordHash: bcrypt.hashSync("password123", 10),
    role: "user",
    createdAt: now,
  };

  const demoCreator: User = {
    id: nanoid(),
    name: "Жишээ Нийлүүлэгч",
    email: "creator@example.com",
    passwordHash: bcrypt.hashSync("password123", 10),
    role: "creator",
    createdAt: now,
  };

  const categories: Category[] = [
    { id: nanoid(), slug: "action", name: "Адал явдалт" },
    { id: nanoid(), slug: "drama", name: "Драм" },
    { id: nanoid(), slug: "comedy", name: "Инээдмийн" },
    { id: nanoid(), slug: "romance", name: "Романтик" },
    { id: nanoid(), slug: "animation", name: "Анимаци" },
    { id: nanoid(), slug: "shounen", name: "Shounen Манга" },
    { id: nanoid(), slug: "adult18", name: "18+" },
  ];

  const byslug = (slug: string) => categories.find((c) => c.slug === slug)!.id;

  const titles: Title[] = [
    {
      id: nanoid(),
      slug: "sample-adventure",
      type: "movie",
      title: "Жишээ адал явдал (Sample Adventure)",
      description:
        "Энэ бол жишээ агуулга бөгөөд платформын функцийг үзүүлэх зорилготой. Та энэ бичлэгийг өөрийн лицензтэй контентоор солино уу.",
      poster: "https://placehold.co/400x600/1a1a2e/f0a500?text=Sample+Adventure",
      backdrop: "https://placehold.co/1280x720/1a1a2e/f0a500?text=Sample+Adventure",
      categoryIds: [byslug("action"), byslug("drama")],
      year: 2026,
      country: "Demo",
      featured: true,
      videoUrl: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      views: 128,
      price: 6900,
      creatorId: demoCreator.id,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: nanoid(),
      slug: "sample-romance",
      type: "movie",
      title: "Жишээ хайр дурлал (Sample Romance)",
      description: "Плейсхолдер кино — жинхэнэ контентоо админ панелаас нэмнэ үү.",
      poster: "https://placehold.co/400x600/2e1a2e/f0a500?text=Sample+Romance",
      backdrop: "https://placehold.co/1280x720/2e1a2e/f0a500?text=Sample+Romance",
      categoryIds: [byslug("romance"), byslug("comedy")],
      year: 2025,
      country: "Demo",
      featured: true,
      videoUrl: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
      views: 76,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: nanoid(),
      slug: "sample-manga",
      type: "manga",
      title: "Жишээ Манга (Sample Manga)",
      description: "Плейсхолдер манга цуврал. Бүлэг бүрт зурагны жагсаалт нэмж болно.",
      poster: "https://placehold.co/400x600/1a2e1a/f0a500?text=Sample+Manga",
      backdrop: "https://placehold.co/1280x720/1a2e1a/f0a500?text=Sample+Manga",
      categoryIds: [byslug("shounen"), byslug("animation")],
      year: 2026,
      featured: true,
      chapters: [
        {
          id: nanoid(),
          number: 1,
          title: "Бүлэг 1: Эхлэл",
          images: [
            "https://placehold.co/800x1200/222/fff?text=Page+1",
            "https://placehold.co/800x1200/222/fff?text=Page+2",
            "https://placehold.co/800x1200/222/fff?text=Page+3",
          ],
        },
        {
          id: nanoid(),
          number: 2,
          title: "Бүлэг 2: Аялал",
          images: [
            "https://placehold.co/800x1200/222/fff?text=Page+1",
            "https://placehold.co/800x1200/222/fff?text=Page+2",
          ],
        },
      ],
      views: 54,
      createdAt: now,
      updatedAt: now,
    },
  ];

  db.data.users.push(admin, demoUser, demoCreator);
  db.data.categories.push(...categories);
  db.data.titles.push(...titles);

  // Жишээ (демо) төлбөртэй худалдан авалт — нийлүүлэгчийн санхүүгийн
  // тайлангийн хуудсыг шууд жишээ өгөгдөлтэй харуулах зорилготой.
  const adventure = titles.find((t) => t.slug === "sample-adventure")!;
  const fin = computeFinance(adventure.price!);
  const purchase: Purchase = {
    id: nanoid(),
    titleId: adventure.id,
    userId: demoUser.id,
    creatorId: demoCreator.id,
    amount: fin.grossRevenue,
    vat: fin.vat,
    profitAfterVat: fin.profitAfterVat,
    platformCut: fin.platformCut,
    creatorCut: fin.creatorCut,
    status: "paid",
    method: "manual",
    createdAt: now,
    paidAt: now,
  };
  db.data.purchases.push(purchase);

  await db.write();

   
  console.log(
    `[seed] Admin account created -> email: ${admin.email} password: ${adminPassword} (please change after first login)`
  );
}
