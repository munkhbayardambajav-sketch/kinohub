import { nanoid } from "nanoid";
import bcrypt from "bcryptjs";
import { getDb } from "./db";
import type {
  Category,
  Comment,
  ContentType,
  Purchase,
  PurchaseStatus,
  Rating,
  Role,
  Title,
  User,
} from "./types";
import { computeFinance, sumFinance, type FinanceLine } from "./finance";

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9Ѐ-ӿ\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export async function listCategories(): Promise<Category[]> {
  const db = await getDb();
  return db.data.categories;
}

export async function createCategory(name: string): Promise<Category> {
  const db = await getDb();
  const base = slugify(name) || nanoid(6);
  let slug = base;
  let i = 1;
  while (db.data.categories.some((c) => c.slug === slug)) {
    slug = `${base}-${i++}`;
  }
  const cat: Category = { id: nanoid(), slug, name };
  db.data.categories.push(cat);
  await db.write();
  return cat;
}

export async function updateCategory(id: string, name: string): Promise<Category | null> {
  const db = await getDb();
  const cat = db.data.categories.find((c) => c.id === id);
  if (!cat) return null;
  cat.name = name;
  await db.write();
  return cat;
}

export async function deleteCategory(id: string): Promise<void> {
  const db = await getDb();
  db.data.categories = db.data.categories.filter((c) => c.id !== id);
  db.data.titles.forEach((t) => {
    t.categoryIds = t.categoryIds.filter((cid) => cid !== id);
  });
  await db.write();
}

export interface TitleFilters {
  type?: ContentType;
  categorySlug?: string;
  q?: string;
  featured?: boolean;
}

export async function listTitles(filters: TitleFilters = {}): Promise<Title[]> {
  const db = await getDb();
  let items = [...db.data.titles];
  if (filters.type) items = items.filter((t) => t.type === filters.type);
  if (filters.featured) items = items.filter((t) => t.featured);
  if (filters.categorySlug) {
    const cat = db.data.categories.find((c) => c.slug === filters.categorySlug);
    if (cat) items = items.filter((t) => t.categoryIds.includes(cat.id));
    else items = [];
  }
  if (filters.q) {
    const q = filters.q.toLowerCase();
    items = items.filter(
      (t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
    );
  }
  return items.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function getTitleBySlug(slug: string): Promise<Title | null> {
  const db = await getDb();
  return db.data.titles.find((t) => t.slug === slug) ?? null;
}

export async function getTitleById(id: string): Promise<Title | null> {
  const db = await getDb();
  return db.data.titles.find((t) => t.id === id) ?? null;
}

export type TitleInput = Omit<Title, "id" | "slug" | "views" | "createdAt" | "updatedAt"> & {
  slug?: string;
};

export async function createTitle(input: TitleInput): Promise<Title> {
  const db = await getDb();
  const base = input.slug ? slugify(input.slug) : slugify(input.title);
  let slug = base || nanoid(6);
  let i = 1;
  while (db.data.titles.some((t) => t.slug === slug)) {
    slug = `${base}-${i++}`;
  }
  const now = new Date().toISOString();
  const title: Title = {
    ...input,
    id: nanoid(),
    slug,
    views: 0,
    createdAt: now,
    updatedAt: now,
  };
  db.data.titles.push(title);
  await db.write();
  return title;
}

export async function updateTitle(
  id: string,
  input: Partial<TitleInput>
): Promise<Title | null> {
  const db = await getDb();
  const title = db.data.titles.find((t) => t.id === id);
  if (!title) return null;
  Object.assign(title, input, { updatedAt: new Date().toISOString() });
  await db.write();
  return title;
}

export async function deleteTitle(id: string): Promise<void> {
  const db = await getDb();
  db.data.titles = db.data.titles.filter((t) => t.id !== id);
  db.data.comments = db.data.comments.filter((c) => c.titleId !== id);
  db.data.ratings = db.data.ratings.filter((r) => r.titleId !== id);
  await db.write();
}

export async function incrementViews(id: string): Promise<void> {
  const db = await getDb();
  const title = db.data.titles.find((t) => t.id === id);
  if (!title) return;
  title.views += 1;
  await db.write();
}

export async function listCommentsForTitle(titleId: string): Promise<Comment[]> {
  const db = await getDb();
  return db.data.comments
    .filter((c) => c.titleId === titleId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function addComment(input: Omit<Comment, "id" | "createdAt">): Promise<Comment> {
  const db = await getDb();
  const comment: Comment = { ...input, id: nanoid(), createdAt: new Date().toISOString() };
  db.data.comments.push(comment);
  await db.write();
  return comment;
}

export async function deleteComment(id: string): Promise<void> {
  const db = await getDb();
  db.data.comments = db.data.comments.filter((c) => c.id !== id);
  await db.write();
}

export async function listAllComments(): Promise<Comment[]> {
  const db = await getDb();
  return [...db.data.comments].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function rateTitle(
  titleId: string,
  userId: string,
  value: number
): Promise<Rating> {
  const db = await getDb();
  let rating = db.data.ratings.find((r) => r.titleId === titleId && r.userId === userId);
  if (rating) {
    rating.value = value;
  } else {
    rating = { id: nanoid(), titleId, userId, value, createdAt: new Date().toISOString() };
    db.data.ratings.push(rating);
  }
  await db.write();
  return rating;
}

export async function getRatingStats(titleId: string): Promise<{ avg: number; count: number }> {
  const db = await getDb();
  const ratings = db.data.ratings.filter((r) => r.titleId === titleId);
  if (ratings.length === 0) return { avg: 0, count: 0 };
  const sum = ratings.reduce((s, r) => s + r.value, 0);
  return { avg: Math.round((sum / ratings.length) * 10) / 10, count: ratings.length };
}

export async function getUserRating(titleId: string, userId: string): Promise<number | null> {
  const db = await getDb();
  const rating = db.data.ratings.find((r) => r.titleId === titleId && r.userId === userId);
  return rating?.value ?? null;
}

export async function listUsers(): Promise<User[]> {
  const db = await getDb();
  return db.data.users;
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const db = await getDb();
  return db.data.users.find((u) => u.email?.toLowerCase() === email.toLowerCase()) ?? null;
}

export async function getUserById(id: string): Promise<User | null> {
  const db = await getDb();
  return db.data.users.find((u) => u.id === id) ?? null;
}

export async function createUser(input: {
  name: string;
  email: string;
  password: string;
  role?: Role;
}): Promise<User> {
  const db = await getDb();
  const existing = db.data.users.find(
    (u) => u.email?.toLowerCase() === input.email.toLowerCase()
  );
  if (existing) throw new Error("Энэ имэйл хаяг бүртгэлтэй байна.");
  const user: User = {
    id: nanoid(),
    name: input.name,
    email: input.email,
    passwordHash: bcrypt.hashSync(input.password, 10),
    role: input.role ?? "user",
    createdAt: new Date().toISOString(),
  };
  db.data.users.push(user);
  await db.write();
  return user;
}

/** Утасны дугаараар хэрэглэгч хайх (утасны дугаараар нэвтрэх урсгалд). */
export async function getUserByPhone(phone: string): Promise<User | null> {
  const db = await getDb();
  return db.data.users.find((u) => u.phone === phone) ?? null;
}

/**
 * Утасны дугаараар шинэ хэрэглэгч үүсгэх (анхны удаа нэвтрэх үед автоматаар
 * дуудагдана). Нууц үг/имэйл шаардахгүй.
 */
export async function createUserByPhone(phone: string): Promise<User> {
  const db = await getDb();
  const existing = db.data.users.find((u) => u.phone === phone);
  if (existing) return existing;
  const user: User = {
    id: nanoid(),
    name: `Хэрэглэгч ${phone.slice(-4)}`,
    phone,
    role: "user",
    createdAt: new Date().toISOString(),
  };
  db.data.users.push(user);
  await db.write();
  return user;
}

export async function listCreators(): Promise<User[]> {
  const db = await getDb();
  return db.data.users.filter((u) => u.role === "creator");
}

export async function setUserRole(id: string, role: Role): Promise<void> {
  const db = await getDb();
  const user = db.data.users.find((u) => u.id === id);
  if (user) {
    user.role = role;
    await db.write();
  }
}

export async function setUserBanned(id: string, banned: boolean): Promise<void> {
  const db = await getDb();
  const user = db.data.users.find((u) => u.id === id);
  if (user) {
    user.banned = banned;
    await db.write();
  }
}

export async function deleteUser(id: string): Promise<void> {
  const db = await getDb();
  db.data.users = db.data.users.filter((u) => u.id !== id);
  db.data.comments = db.data.comments.filter((c) => c.userId !== id);
  db.data.ratings = db.data.ratings.filter((r) => r.userId !== id);
  await db.write();
}

// ---------------------------------------------------------------------------
// Purchases / monetization
// ---------------------------------------------------------------------------

export async function createPendingPurchase(input: {
  titleId: string;
  userId: string;
  creatorId?: string;
  price: number;
  method: "qpay" | "manual";
  qpayInvoiceId?: string;
  status?: PurchaseStatus;
}): Promise<Purchase> {
  const db = await getDb();
  const fin = computeFinance(input.price);
  const purchase: Purchase = {
    id: nanoid(),
    titleId: input.titleId,
    userId: input.userId,
    creatorId: input.creatorId,
    amount: fin.grossRevenue,
    vat: fin.vat,
    profitAfterVat: fin.profitAfterVat,
    platformCut: fin.platformCut,
    creatorCut: fin.creatorCut,
    status: input.status ?? "pending",
    method: input.method,
    qpayInvoiceId: input.qpayInvoiceId,
    createdAt: new Date().toISOString(),
  };
  db.data.purchases.push(purchase);
  await db.write();
  return purchase;
}

export async function getPurchaseById(id: string): Promise<Purchase | null> {
  const db = await getDb();
  return db.data.purchases.find((p) => p.id === id) ?? null;
}

export async function markPurchasePaid(
  id: string,
  qpayPaymentId?: string
): Promise<Purchase | null> {
  const db = await getDb();
  const purchase = db.data.purchases.find((p) => p.id === id);
  if (!purchase) return null;
  if (purchase.status !== "paid") {
    purchase.status = "paid";
    purchase.paidAt = new Date().toISOString();
    if (qpayPaymentId) purchase.qpayPaymentId = qpayPaymentId;
    await db.write();
  }
  return purchase;
}

export async function markPurchaseFailed(id: string): Promise<void> {
  const db = await getDb();
  const purchase = db.data.purchases.find((p) => p.id === id);
  if (purchase && purchase.status === "pending") {
    purchase.status = "failed";
    await db.write();
  }
}

export async function hasUserPurchased(titleId: string, userId: string): Promise<boolean> {
  const db = await getDb();
  return db.data.purchases.some(
    (p) => p.titleId === titleId && p.userId === userId && p.status === "paid"
  );
}

export async function createManualPurchase(input: {
  titleId: string;
  userId: string;
}): Promise<Purchase> {
  const title = await getTitleById(input.titleId);
  if (!title) throw new Error("Контент олдсонгүй.");
  if (!title.price) throw new Error("Энэ контент төлбөргүй тул худалдан авалт бүртгэх шаардлагагүй.");
  const purchase = await createPendingPurchase({
    titleId: input.titleId,
    userId: input.userId,
    creatorId: title.creatorId,
    price: title.price,
    method: "manual",
    status: "paid",
  });
  const db = await getDb();
  const p = db.data.purchases.find((x) => x.id === purchase.id)!;
  p.paidAt = new Date().toISOString();
  await db.write();
  return p;
}

export async function listAllPurchases(): Promise<Purchase[]> {
  const db = await getDb();
  return [...db.data.purchases].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export interface CreatorReportLine extends FinanceLine {
  titleId: string;
  titleName: string;
  type: ContentType;
  price: number;
  salesCount: number;
}

export interface CreatorReport {
  lines: CreatorReportLine[];
  total: FinanceLine;
}

async function buildReportForTitles(
  titles: Title[],
  range?: { from?: string; to?: string }
): Promise<CreatorReport> {
  const db = await getDb();
  const fromTime = range?.from ? new Date(range.from).getTime() : -Infinity;
  // include the entire "to" day
  const toTime = range?.to ? new Date(range.to).getTime() + 24 * 60 * 60 * 1000 - 1 : Infinity;

  const lines: CreatorReportLine[] = titles.map((title) => {
    const sales = db.data.purchases.filter((p) => {
      if (p.titleId !== title.id || p.status !== "paid" || !p.paidAt) return false;
      const t = new Date(p.paidAt).getTime();
      return t >= fromTime && t <= toTime;
    });
    const gross = sales.reduce((s, p) => s + p.amount, 0);
    const fin = computeFinance(gross);
    return {
      ...fin,
      titleId: title.id,
      titleName: title.title,
      type: title.type,
      price: title.price ?? 0,
      salesCount: sales.length,
    };
  });

  const total = sumFinance(lines);
  return { lines, total };
}

export async function buildCreatorReport(
  creatorId: string,
  range?: { from?: string; to?: string }
): Promise<CreatorReport> {
  const db = await getDb();
  const titles = db.data.titles.filter((t) => t.creatorId === creatorId);
  return buildReportForTitles(titles, range);
}

// Бүх (creatorId-той эсвэл байхгүй ч гэсэн) үнэтэй контентыг багтаасан
// платформ даяарх нэгдсэн санхүүгийн тайлан — админд зориулав.
export async function buildPlatformReport(range?: {
  from?: string;
  to?: string;
}): Promise<CreatorReport> {
  const db = await getDb();
  const titles = db.data.titles.filter((t) => !!t.price);
  return buildReportForTitles(titles, range);
}

export async function getStats() {
  const db = await getDb();
  const totalViews = db.data.titles.reduce((s, t) => s + t.views, 0);
  const paidPurchases = db.data.purchases.filter((p) => p.status === "paid");
  const totalPlatformRevenue = paidPurchases.reduce((s, p) => s + p.platformCut, 0);
  const totalCreatorPayouts = paidPurchases.reduce((s, p) => s + p.creatorCut, 0);
  return {
    totalUsers: db.data.users.length,
    totalCreators: db.data.users.filter((u) => u.role === "creator").length,
    totalTitles: db.data.titles.length,
    totalMovies: db.data.titles.filter((t) => t.type === "movie").length,
    totalManga: db.data.titles.filter((t) => t.type === "manga").length,
    totalComments: db.data.comments.length,
    totalViews,
    totalSales: paidPurchases.length,
    totalPlatformRevenue,
    totalCreatorPayouts,
  };
}
