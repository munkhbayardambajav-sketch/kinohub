"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { addComment, deleteComment, getTitleById } from "@/lib/repo";

export async function addCommentAction(formData: FormData) {
  const session = await auth();
  if (!session?.user?.id) throw new Error("Нэвтэрсэн байх шаардлагатай.");

  const titleId = String(formData.get("titleId") || "");
  const text = String(formData.get("text") || "").trim();
  if (!titleId || !text) return;

  const title = await getTitleById(titleId);
  if (!title) return;

  await addComment({
    titleId,
    userId: session.user.id,
    userName: session.user.name || "Хэрэглэгч",
    text: text.slice(0, 1000),
  });

  revalidatePath(`/title/${title.slug}`);
}

export async function deleteCommentAction(formData: FormData) {
  const session = await auth();
  if (!session?.user) throw new Error("Нэвтэрсэн байх шаардлагатай.");

  const commentId = String(formData.get("commentId") || "");
  const slug = String(formData.get("slug") || "");
  if (!commentId) return;

  // Only admin can delete via this generic action; owner-delete handled separately if needed.
  if (session.user.role !== "admin") throw new Error("Зөвшөөрөлгүй.");

  await deleteComment(commentId);
  if (slug) revalidatePath(`/title/${slug}`);
  revalidatePath("/admin/comments");
}
