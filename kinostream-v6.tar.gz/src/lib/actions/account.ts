"use server";

import { redirect } from "next/navigation";
import { AuthError } from "next-auth";
import { signIn } from "@/auth";
import { createUser, createUserByPhone, getUserByPhone } from "@/lib/repo";
import { generateOtp } from "@/lib/otp";
import { createVerifySession, generateVerificationCode, getVerifySessionStatus, VerifyMnError } from "@/lib/verifyMn";
import { consumeVerifySession, getVerifySessionPhone, rememberVerifySession } from "@/lib/verifySessionStore";

export async function registerAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  if (!name || !email || !password) {
    return { error: "Бүх талбарыг бөглөнө үү." };
  }
  if (password.length < 6) {
    return { error: "Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой." };
  }

  try {
    await createUser({ name, email, password, role: "user" });
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Алдаа гарлаа." };
  }

  try {
    await signIn("credentials", { email, password, redirectTo: "/" });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Бүртгэл үүслээ, гэхдээ автоматаар нэвтрэхэд алдаа гарлаа. Дахин нэвтэрнэ үү." };
    }
    throw e;
  }

  redirect("/");
}

export async function loginAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const callbackUrl = String(formData.get("callbackUrl") || "/");

  try {
    await signIn("credentials", { email, password, redirectTo: callbackUrl });
  } catch (e) {
    if (e instanceof AuthError) {
      return { error: "Имэйл эсвэл нууц үг буруу байна." };
    }
    throw e;
  }

  return {};
}

// ---------------------------------------------------------------------------
// Утасны дугаараар нэвтрэх:
//  - Анхны удаа тухайн дугаараар нэвтрэх үед аккаунт автоматаар үүсэж, нэн
//    даруй нэвтэрдэг (код харуулахгүй, дотоод bootstrap код ашиглана).
//  - Дараагийн удаа бүрд verify.mn ашиглан ЖИНХЭНЭ SMS баталгаажуулалт
//    хийнэ: хэрэглэгч бидний өгсөн 6 оронтой кодыг 144773 тусгай дугаарт
//    SMS-ээр илгээснээр систем автоматаар таньж нэвтрүүлнэ.
// ---------------------------------------------------------------------------

export type PhoneLoginState = {
  stage: "phone" | "verify";
  phone?: string;
  sessionId?: string;
  smsUri?: string;
  displayInstruction?: string;
  expiresAt?: string;
  error?: string;
};

function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 11 && digits.startsWith("976")) return digits.slice(3);
  return digits;
}

export async function phoneLoginAction(
  _prevState: PhoneLoginState | undefined,
  formData: FormData
): Promise<PhoneLoginState> {
  const phone = normalizePhone(String(formData.get("phone") || ""));
  const callbackUrl = String(formData.get("callbackUrl") || "/");

  if (!/^\d{8}$/.test(phone)) {
    return { stage: "phone", error: "Утасны дугаараа 8 оронтой тоогоор зөв оруулна уу." };
  }

  const existing = await getUserByPhone(phone);

  if (existing?.banned) {
    return { stage: "phone", error: "Энэ дугаар хориглогдсон байна." };
  }

  if (!existing) {
    // Анхны удаа: аккаунт үүсгээд шууд нэвтрүүлнэ (SMS баталгаажуулалт байхгүй).
    await createUserByPhone(phone);
    const bootstrapCode = generateOtp(phone, 60_000);
    try {
      await signIn("phone", { phone, code: bootstrapCode, redirectTo: callbackUrl });
    } catch (e) {
      if (e instanceof AuthError) {
        return { stage: "phone", error: "Нэвтрэхэд алдаа гарлаа. Дахин оролдоно уу." };
      }
      throw e;
    }
    return { stage: "phone" };
  }

  // Дараагийн удаа: verify.mn-ээр жинхэнэ SMS баталгаажуулах SESSION үүсгэнэ.
  const code = generateVerificationCode();
  let session;
  try {
    session = await createVerifySession(phone, code);
  } catch (e) {
    const message = e instanceof VerifyMnError ? e.message : "Тодорхойгүй алдаа гарлаа.";
    return {
      stage: "phone",
      error: `Баталгаажуулах SMS үүсгэхэд алдаа гарлаа: ${message} Дахин оролдоно уу.`,
    };
  }

  rememberVerifySession(session.sessionId, phone, new Date(session.expiresAt).getTime());

  return {
    stage: "verify",
    phone,
    sessionId: session.sessionId,
    smsUri: session.smsUri,
    displayInstruction: session.displayInstruction,
    expiresAt: session.expiresAt,
  };
}

// Клиент 3 секунд тутам polling хийж дуудна: verify.mn дээрх SESSION-ийн
// статусыг шалгаад, баталгаажсан бол (VERIFIED) шууд нэвтрүүлж чиглүүлнэ.
export type VerifyPollResult = { status: "pending" | "expired" | "error"; error?: string };

export async function checkPhoneVerificationAction(
  phone: string,
  sessionId: string,
  callbackUrl: string
): Promise<VerifyPollResult> {
  const boundPhone = getVerifySessionPhone(sessionId);
  if (!boundPhone || boundPhone !== phone) {
    return { status: "expired" };
  }

  let status;
  try {
    status = await getVerifySessionStatus(sessionId);
  } catch (e) {
    return { status: "error", error: e instanceof VerifyMnError ? e.message : "Алдаа гарлаа." };
  }

  if (status.sessionStatus === "EXPIRED") {
    consumeVerifySession(sessionId);
    return { status: "expired" };
  }

  if (status.sessionStatus !== "VERIFIED") {
    return { status: "pending" };
  }

  try {
    await signIn("phone", { phone, sessionId, redirectTo: callbackUrl });
  } catch (e) {
    if (e instanceof AuthError) {
      return { status: "error", error: "Нэвтрэхэд алдаа гарлаа." };
    }
    throw e; // NEXT_REDIRECT — амжилттай нэвтэрсэн тул шилжинэ.
  }

  return { status: "pending" };
}
