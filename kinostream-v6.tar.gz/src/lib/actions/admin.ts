"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import {
  createTitle,
  updateTitle,
  deleteTitle,
  createCategory,
  updateCategory,
  deleteCategory,
  setUserRole,
  setUserBanned,
  deleteUser,
  deleteComment,
  createUser,
  createManualPurchase,
} from "@/lib/repo";
import type { ContentType, MangaChapter, Role } from "@/lib/types";

async function requireAdmin() {
  const session = await auth();
  if (session?.user?.role !== "admin") {
    throw new Error("Зөвшөөрөлгүй үйлдэл.");
  }
  return session;
}

function parseCategoryIds(formData: FormData): string[] {
  return formData.getAll("categoryIds").map(String).filter(Boolean);
}

function parseChapters(formData: FormData): MangaChapter[] {
  const raw = String(formData.get("chaptersJson") || "[]");
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

export async function createTitleAction(formData: FormData) {
  await requireAdmin();

  const type = String(formData.get("type") || "movie") as ContentType;

  const title = await createTitle({
    type,
    title: String(formData.get("title") || ""),
    description: String(formData.get("description") || ""),
    poster: String(formData.get("poster") || ""),
    backdrop: String(formData.get("backdrop") || "") || undefined,
    categoryIds: parseCategoryIds(formData),
    year: Number(formData.get("year")) || undefined,
    country: String(formData.get("country") || "") || undefined,
    ageRestricted: formData.get("ageRestricted") === "on",
    featured: formData.get("featured") === "on",
    videoUrl: type === "movie" ? String(formData.get("videoUrl") || "") || undefined : undefined,
    chapters: type === "manga" ? parseChapters(formData) : undefined,
    price: Number(formData.get("price")) || undefined,
    creatorId: String(formData.get("creatorId") || "") || undefined,
  });

  revalidatePath("/admin/titles");
  revalidatePath("/");
  redirect(`/admin/titles/${title.id}/edit`);
}

export async function updateTitleAction(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") || "");
  const type = String(formData.get("type") || "movie") as ContentType;
  if (!id) return;

  await updateTitle(id, {
    type,
    title: String(formData.get("title") || ""),
    description: String(formData.get("description") || ""),
    poster: String(formData.get("poster") || ""),
    backdrop: String(formData.get("backdrop") || "") || undefined,
    categoryIds: parseCategoryIds(formData),
    year: Number(formData.get("year")) || undefined,
    country: String(formData.get("country") || "") || undefined,
    ageRestricted: formData.get("ageRestricted") === "on",
    featured: formData.get("featured") === "on",
    videoUrl: type === "movie" ? String(formData.get("videoUrl") || "") || undefined : undefined,
    chapters: type === "manga" ? parseChapters(formData) : undefined,
    price: Number(formData.get("price")) || undefined,
    creatorId: String(formData.get("creatorId") || "") || undefined,
  });

  revalidatePath("/admin/titles");
  revalidatePath("/");
  redirect("/admin/titles");
}

export async function deleteTitleAction(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await deleteTitle(id);
  revalidatePath("/admin/titles");
  revalidatePath("/");
}

export async function createCategoryAction(formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name") || "").trim();
  if (!name) return;
  await createCategory(name);
  revalidatePath("/admin/categories");
}

export async function updateCategoryAction(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") || "");
  const name = String(formData.get("name") || "").trim();
  if (!id || !name) return;
  await updateCategory(id, name);
  revalidatePath("/admin/categories");
}

export async function deleteCategoryAction(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await deleteCategory(id);
  revalidatePath("/admin/categories");
}

export async function setUserRoleAction(formData: FormData) {
  const session = await requireAdmin();
  const id = String(formData.get("id") || "");
  const role = String(formData.get("role") || "user") as Role;
  if (!id) return;
  if (id === session?.user?.id && role !== "admin") {
    // prevent self-demotion lockout
    return;
  }
  await setUserRole(id, role);
  revalidatePath("/admin/users");
}

export async function adminCreateUserAction(
  _prevState: { error?: string } | undefined,
  formData: FormData
): Promise<{ error?: string }> {
  await requireAdmin();
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const role = String(formData.get("role") || "user") as Role;

  if (!name || !email || !password) return { error: "Бүх талбарыг бөглөнө үү." };
  if (password.length < 6) return { error: "Нууц үг хамгийн багадаа 6 тэмдэгт байх ёстой." };

  try {
    await createUser({ name, email, password, role });
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Алдаа гарлаа." };
  }

  revalidatePath("/admin/users");
  return {};
}

export async function createManualPurchaseAction(formData: FormData) {
  await requireAdmin();
  const titleId = String(formData.get("titleId") || "");
  const userId = String(formData.get("userId") || "");
  if (!titleId || !userId) return;
  await createManualPurchase({ titleId, userId });
  revalidatePath("/admin/purchases");
  revalidatePath("/admin");
  revalidatePath("/creator/reports");
}

export async function toggleBanAction(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") || "");
  const banned = String(formData.get("banned") || "false") === "true";
  if (!id) return;
  await setUserBanned(id, banned);
  revalidatePath("/admin/users");
}

export async function deleteUserAction(formData: FormData) {
  const session = await requireAdmin();
  const id = String(formData.get("id") || "");
  if (!id || id === session?.user?.id) return;
  await deleteUser(id);
  revalidatePath("/admin/users");
}

export async function deleteCommentAdminAction(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await deleteComment(id);
  revalidatePath("/admin/comments");
}
