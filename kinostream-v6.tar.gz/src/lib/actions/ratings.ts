"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { getTitleById, rateTitle } from "@/lib/repo";

export async function rateAction(formData: FormData) {
  const session = await auth();
  if (!session?.user?.id) throw new Error("Нэвтэрсэн байх шаардлагатай.");

  const titleId = String(formData.get("titleId") || "");
  const value = Number(formData.get("value") || 0);
  if (!titleId || value < 1 || value > 5) return;

  const title = await getTitleById(titleId);
  if (!title) return;

  await rateTitle(titleId, session.user.id, value);
  revalidatePath(`/title/${title.slug}`);
}
