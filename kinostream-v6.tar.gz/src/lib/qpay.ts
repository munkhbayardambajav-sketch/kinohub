// QPay (Bonum Systems) Merchant v2 API client.
//
// АНХААРУУЛГА: Танд одоогоор QPay-ийн мерчант эрх (нэвтрэх мэдээлэл) байхгүй
// байгаа тул энэ модуль нь QPay Merchant V2-ийн нийтэд түгээмэл баримтлагддаг
// бүтцээр бичигдсэн (auth/token → invoice → payment/check урсгал). Бодит
// мерчант эрхээ авсны дараа sandbox орчинд заавал туршиж, хэрэв QPay талын
// талбарын нэрс өөр байвал энэ файлыг тохируулаарай (endpoint зөвхөн энд
// байгаа тул засварлахад амархан).
//
// Шаардлагатай орчны хувьсагчид (.env.local):
//   QPAY_BASE_URL       - жишээ нь https://merchant.qpay.mn (эсвэл sandbox URL)
//   QPAY_USERNAME
//   QPAY_PASSWORD
//   QPAY_INVOICE_CODE   - QPay-ээс танд өгсөн invoice code

interface QpayTokenResponse {
  token_type: string;
  access_token: string;
  refresh_token: string;
  expires_in: number;
}

export interface QpayInvoiceUrl {
  name: string;
  description: string;
  logo?: string;
  link: string;
}

export interface QpayInvoiceResult {
  invoice_id: string;
  qr_text: string;
  qr_image: string; // base64 PNG
  qPay_shortUrl?: string;
  urls?: QpayInvoiceUrl[];
}

export interface QpayCheckResult {
  count: number;
  paid_amount: number;
  rows: Array<{
    payment_id: string;
    payment_status: string; // "PAID" гэх мэт
    payment_amount: string;
  }>;
}

function isQpayConfigured() {
  return Boolean(
    process.env.QPAY_BASE_URL &&
      process.env.QPAY_USERNAME &&
      process.env.QPAY_PASSWORD &&
      process.env.QPAY_INVOICE_CODE
  );
}

let cachedToken: { accessToken: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (!isQpayConfigured()) {
    throw new Error(
      "QPay тохиргоо дутуу байна (QPAY_BASE_URL / QPAY_USERNAME / QPAY_PASSWORD / QPAY_INVOICE_CODE). .env.local-д мерчант эрхээ бөглөнө үү."
    );
  }

  if (cachedToken && cachedToken.expiresAt > Date.now() + 10_000) {
    return cachedToken.accessToken;
  }

  const basic = Buffer.from(
    `${process.env.QPAY_USERNAME}:${process.env.QPAY_PASSWORD}`
  ).toString("base64");

  const res = await fetch(`${process.env.QPAY_BASE_URL}/v2/auth/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${basic}` },
  });

  if (!res.ok) {
    throw new Error(`QPay auth амжилтгүй: ${res.status} ${await res.text()}`);
  }

  const data = (await res.json()) as QpayTokenResponse;
  cachedToken = {
    accessToken: data.access_token,
    expiresAt: Date.now() + data.expires_in * 1000,
  };
  return cachedToken.accessToken;
}

export function isQpayReady(): boolean {
  return isQpayConfigured();
}

export async function createInvoice(params: {
  amount: number;
  description: string;
  senderInvoiceNo: string; // манай талын дахин давтагдашгүй дугаар (purchase id)
  callbackUrl: string;
}): Promise<QpayInvoiceResult> {
  const token = await getAccessToken();

  const res = await fetch(`${process.env.QPAY_BASE_URL}/v2/invoice`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      invoice_code: process.env.QPAY_INVOICE_CODE,
      sender_invoice_no: params.senderInvoiceNo,
      invoice_receiver_code: "terminal",
      invoice_description: params.description,
      amount: params.amount,
      callback_url: params.callbackUrl,
    }),
  });

  if (!res.ok) {
    throw new Error(`QPay нэхэмжлэл үүсгэхэд алдаа гарлаа: ${res.status} ${await res.text()}`);
  }

  return (await res.json()) as QpayInvoiceResult;
}

export async function checkPayment(invoiceId: string): Promise<QpayCheckResult> {
  const token = await getAccessToken();

  const res = await fetch(`${process.env.QPAY_BASE_URL}/v2/payment/check`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      object_type: "INVOICE",
      object_id: invoiceId,
      offset: { page_number: 1, page_limit: 100 },
    }),
  });

  if (!res.ok) {
    throw new Error(`QPay төлбөр шалгахад алдаа гарлаа: ${res.status} ${await res.text()}`);
  }

  return (await res.json()) as QpayCheckResult;
}
