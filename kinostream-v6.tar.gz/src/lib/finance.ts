// Санхүүгийн тайлангийн тооцоолол.
// Үнэ (price) нь НӨАТ шингэсэн (VAT-inclusive) дүн гэж үзнэ.
//   НӨАТ = Нийт орлого / 11   (10%-ийн НӨАТ-г НӨАТ шингэсэн дүнгээс салгаж авах стандарт томьёо: gross * 10/110)
//   Ашиг (НӨАТ хассаны дараах) = Нийт орлого - НӨАТ
//   Апп шимтгэл (платформын хувь) = Ашиг * PLATFORM_CUT_RATE
//   Хуваарилах дүн (нийлүүлэгчид өгөх, НӨАТ-гүй) = Ашиг - Апп шимтгэл

export const VAT_DIVISOR = 11; // gross / 11 == VAT амоунт (10% НӨАТ, gross дотор шингэсэн)
export const PLATFORM_CUT_RATE = 0.4; // манай компанийн авдаг хувь
export const CREATOR_CUT_RATE = 1 - PLATFORM_CUT_RATE;

export interface FinanceLine {
  grossRevenue: number;
  vat: number;
  profitAfterVat: number;
  platformCut: number;
  creatorCut: number;
}

export function computeFinance(grossRevenue: number): FinanceLine {
  const vat = Math.round(grossRevenue / VAT_DIVISOR);
  const profitAfterVat = grossRevenue - vat;
  const platformCut = Math.round(profitAfterVat * PLATFORM_CUT_RATE);
  const creatorCut = profitAfterVat - platformCut;
  return { grossRevenue, vat, profitAfterVat, platformCut, creatorCut };
}

export function computeFinanceForSale(price: number): FinanceLine {
  return computeFinance(price);
}

export function sumFinance(lines: FinanceLine[]): FinanceLine {
  return lines.reduce(
    (acc, l) => ({
      grossRevenue: acc.grossRevenue + l.grossRevenue,
      vat: acc.vat + l.vat,
      profitAfterVat: acc.profitAfterVat + l.profitAfterVat,
      platformCut: acc.platformCut + l.platformCut,
      creatorCut: acc.creatorCut + l.creatorCut,
    }),
    { grossRevenue: 0, vat: 0, profitAfterVat: 0, platformCut: 0, creatorCut: 0 }
  );
}

export function formatMnt(n: number): string {
  return new Intl.NumberFormat("mn-MN").format(Math.round(n));
}
