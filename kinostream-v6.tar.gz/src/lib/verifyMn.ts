// Verify.MN — Монголын MO SMS (Mobile-Originated) утас баталгаажуулах API.
// https://verify.mn/app/docs/
//
// Ажиллах зарчим: хэрэглэгч бидний өгсөн 6 оронтой кодыг 144773 тусгай
// дугаарт SMS-ээр илгээнэ. Бид SESSION үүсгээд (POST /sessions), дараа нь
// статусыг polling хийж шалгана (GET /sessions/:id) — public HTTPS callback
// URL тохируулаагүй тул (сервер дээр SSL байхгүй) polling горимоор ажиллана.

const VERIFY_MN_BASE_URL = "https://api.verify.mn";

export class VerifyMnError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "VerifyMnError";
    this.status = status;
  }
}

export type CreateSessionResult = {
  sessionId: string;
  phone: string;
  shortcode: string;
  text: string;
  smsUri: string;
  displayInstruction: string;
  expiresAt: string; // ISO
};

export type SessionStatusResult = {
  sessionId: string;
  sessionStatus: "PENDING" | "VERIFIED" | "EXPIRED";
  callbackStatus: "PENDING" | "SENT" | "FAILED";
  verifiedAt?: string;
  expiresAt: string;
};

function apiKey(): string {
  const key = process.env.VERIFY_MN_API_KEY;
  if (!key) {
    throw new VerifyMnError("VERIFY_MN_API_KEY тохируулагдаагүй байна.");
  }
  return key;
}

async function parseJsonSafe(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

function extractMessage(data: unknown, fallback: string): string {
  if (data && typeof data === "object" && "message" in data) {
    const m = (data as { message?: unknown }).message;
    if (typeof m === "string") return m;
    if (Array.isArray(m) && m.every((x) => typeof x === "string")) return m.join(", ");
  }
  return fallback;
}

/** Шинэ баталгаажуулах SESSION үүсгэнэ (callback тохируулаагүй тул polling ашиглана). */
export async function createVerifySession(
  phone: string,
  text: string
): Promise<CreateSessionResult> {
  const res = await fetch(`${VERIFY_MN_BASE_URL}/sessions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey()}`,
    },
    body: JSON.stringify({ phone, text }),
    cache: "no-store",
  });
  const data = await parseJsonSafe(res);
  if (!res.ok) {
    throw new VerifyMnError(extractMessage(data, `Verify.mn алдаа (${res.status})`), res.status);
  }
  return data as CreateSessionResult;
}

/** SESSION-ий одоогийн статусыг шалгана (API KEY шаардахгүй). */
export async function getVerifySessionStatus(sessionId: string): Promise<SessionStatusResult> {
  const res = await fetch(`${VERIFY_MN_BASE_URL}/sessions/${encodeURIComponent(sessionId)}`, {
    method: "GET",
    cache: "no-store",
  });
  const data = await parseJsonSafe(res);
  if (!res.ok) {
    throw new VerifyMnError(extractMessage(data, `Verify.mn алдаа (${res.status})`), res.status);
  }
  return data as SessionStatusResult;
}

/** Санамсаргүй 6 оронтой баталгаажуулах код (verify.mn руу session текст болгон илгээнэ). */
export function generateVerificationCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}
