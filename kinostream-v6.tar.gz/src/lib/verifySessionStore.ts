// verify.mn-ийн GET /sessions/:id хариу дотор аль дугаар байсныг буцаадаггүй
// (зөвхөн sessionStatus, expiresAt, г.м.) тул бид SESSION үүсгэх мөчид өөрсдөө
// sessionId -> утасны дугаар холбоосыг санах ойд хадгална. authorize() дотор
// зөвхөн ЭНЭ холбоосоор дамжуулж дугаарыг олно (клиентээс ирсэн "phone"
// талбарт итгэхгүй) — ингэснээр өөр хэн нэгний баталгаажсан session-ийг өөр
// дугаараар нэвтрэхэд ашиглах боломжгүй болно.

type Entry = { phone: string; expiresAt: number };

declare global {
  var __kinostream_verify_session_store__: Map<string, Entry> | undefined;
}

function store(): Map<string, Entry> {
  if (!globalThis.__kinostream_verify_session_store__) {
    globalThis.__kinostream_verify_session_store__ = new Map();
  }
  return globalThis.__kinostream_verify_session_store__;
}

export function rememberVerifySession(sessionId: string, phone: string, expiresAtMs: number): void {
  store().set(sessionId, { phone, expiresAt: expiresAtMs });
}

/** sessionId-д холбоотой дугаарыг буцаана; хугацаа дууссан/олдоогүй бол null. */
export function getVerifySessionPhone(sessionId: string): string | null {
  const rec = store().get(sessionId);
  if (!rec) return null;
  if (Date.now() > rec.expiresAt) {
    store().delete(sessionId);
    return null;
  }
  return rec.phone;
}

export function consumeVerifySession(sessionId: string): void {
  store().delete(sessionId);
}
