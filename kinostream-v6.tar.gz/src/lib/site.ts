// Central branding config. The user should replace these with their own
// name/logo/tagline — nothing here is copied from any existing site.
export const SITE = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || "MediaHub",
  tagline: "Кино, манга үзэх платформ",
};
