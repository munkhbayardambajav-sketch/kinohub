export type Role = "admin" | "creator" | "user";

export type ContentType = "movie" | "manga";

export interface User {
  id: string;
  name: string;
  email?: string;
  passwordHash?: string;
  phone?: string;
  role: Role;
  banned?: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
}

export interface MangaChapter {
  id: string;
  number: number;
  title: string;
  images: string[]; // ordered page image URLs
}

export interface Title {
  id: string;
  slug: string;
  type: ContentType;
  title: string;
  description: string;
  poster: string; // image URL
  backdrop?: string;
  categoryIds: string[];
  year?: number;
  country?: string;
  ageRestricted?: boolean;
  featured?: boolean;
  // movie fields
  videoUrl?: string;
  // manga fields
  chapters?: MangaChapter[];
  views: number;
  createdAt: string;
  updatedAt: string;
  // monetization
  price?: number; // MNT, VAT-inclusive. 0/undefined = free to watch
  creatorId?: string; // owner (role: "creator") this content's revenue belongs to
}

export interface Comment {
  id: string;
  titleId: string;
  userId: string;
  userName: string;
  text: string;
  createdAt: string;
}

export interface Rating {
  id: string;
  titleId: string;
  userId: string;
  value: number; // 1-5
  createdAt: string;
}

export type PurchaseStatus = "pending" | "paid" | "failed" | "cancelled";

export interface Purchase {
  id: string;
  titleId: string;
  userId: string;
  creatorId?: string;
  amount: number; // gross amount paid (VAT-inclusive), MNT
  vat: number;
  profitAfterVat: number;
  platformCut: number; // 40%
  creatorCut: number; // 60%
  status: PurchaseStatus;
  method: "qpay" | "manual"; // manual = admin-recorded (cash/offline) purchase
  qpayInvoiceId?: string;
  qpayPaymentId?: string;
  createdAt: string;
  paidAt?: string;
}

export interface DbSchema {
  users: User[];
  categories: Category[];
  titles: Title[];
  comments: Comment[];
  ratings: Rating[];
  purchases: Purchase[];
}
