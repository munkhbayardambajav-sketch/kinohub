// Демо/түр зуурын нэг удаагийн код (OTP) хадгалах сан.
//
// ЖИЧ: Энэ бол ЖИНХЭНЭ SMS gateway холбогдоогүй үед ашиглах ТҮР ШИЙДЭЛ.
// Кодыг серверийн санах ойд (in-memory) хадгалж байгаа тул зөвхөн ганц
// процесс (pm2 fork mode) дээр найдвартай ажиллана. Ирээдүйд жинхэнэ
// оператор/SMS gateway холбогдвол энэ файлыг тэдгээрийн API-аар солино.

type OtpRecord = { code: string; expiresAt: number };

declare global {

  var __kinostream_otp_store__: Map<string, OtpRecord> | undefined;
}

function store(): Map<string, OtpRecord> {
  if (!globalThis.__kinostream_otp_store__) {
    globalThis.__kinostream_otp_store__ = new Map();
  }
  return globalThis.__kinostream_otp_store__;
}

/** Шинэ 4 оронтой код үүсгэж, өгөгдсөн хугацаагаар хадгална (анхныхаар 5 минут). */
export function generateOtp(phone: string, ttlMs: number = 5 * 60 * 1000): string {
  const code = String(Math.floor(1000 + Math.random() * 9000));
  store().set(phone, { code, expiresAt: Date.now() + ttlMs });
  return code;
}

/** Кодыг шалгаад зөв бол нэг удаа хэрэглэгдсэн гэж устгана (дахин ашиглах боломжгүй). */
export function verifyOtp(phone: string, code: string): boolean {
  const rec = store().get(phone);
  if (!rec) return false;
  if (Date.now() > rec.expiresAt) {
    store().delete(phone);
    return false;
  }
  if (rec.code !== code) return false;
  store().delete(phone);
  return true;
}
