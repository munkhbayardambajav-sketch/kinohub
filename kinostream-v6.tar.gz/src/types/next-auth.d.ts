import type { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id?: string;
      role?: "admin" | "creator" | "user";
    } & DefaultSession["user"];
  }

  interface User {
    role?: "admin" | "creator" | "user";
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id?: string;
    role?: "admin" | "creator" | "user";
  }
}
