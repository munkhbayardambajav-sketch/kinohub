import type { NextAuthConfig } from "next-auth";

// Edge-safe config: no providers with Node-only deps (bcrypt, fs via lowdb) here.
// This is used directly by proxy.ts (runs on the Edge runtime) and is merged
// into the full config in auth.ts (used by API routes / server components).
export const authConfig = {
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  providers: [],
  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.role = (user as { role?: string }).role ?? "user";
        token.id = (user as { id?: string }).id;
      }
      return token;
    },
    session({ session, token }) {
      if (session.user) {
        session.user.role = token.role as "admin" | "creator" | "user" | undefined;
        session.user.id = token.id as string;
      }
      return session;
    },
    authorized({ auth, request }) {
      const { pathname } = request.nextUrl;
      if (pathname.startsWith("/admin")) {
        return auth?.user?.role === "admin";
      }
      if (pathname.startsWith("/creator")) {
        return auth?.user?.role === "creator" || auth?.user?.role === "admin";
      }
      return true;
    },
  },
} satisfies NextAuthConfig;
