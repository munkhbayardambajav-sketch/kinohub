import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { getDb } from "@/lib/db";
import { authConfig } from "@/auth.config";
import { verifyOtp } from "@/lib/otp";
import { getVerifySessionStatus } from "@/lib/verifyMn";
import { consumeVerifySession, getVerifySessionPhone } from "@/lib/verifySessionStore";

export const { handlers, signIn, signOut, auth } = NextAuth({
  ...authConfig,
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Имэйл", type: "email" },
        password: { label: "Нууц үг", type: "password" },
      },
      authorize: async (credentials) => {
        const email = (credentials?.email as string | undefined)?.toLowerCase().trim();
        const password = credentials?.password as string | undefined;
        if (!email || !password) return null;

        const db = await getDb();
        const user = db.data.users.find((u) => u.email?.toLowerCase() === email);
        if (!user || !user.passwordHash) return null;
        if (user.banned) return null;

        const valid = bcrypt.compareSync(password, user.passwordHash);
        if (!valid) return null;

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
    // Утасны дугаараар нэвтрэх/бүртгүүлэх урсгал:
    //  - Анхны удаа тухайн дугаараар нэвтрэх үед аккаунт автоматаар үүсэж,
    //    нэн даруй нэвтэрдэг (дотооддоо нэг удаагийн bootstrap код ашиглан
    //    шууд нэвтрүүлдэг — хэрэглэгчид ямар ч код харагдахгүй).
    //  - Дараагийн удаа нэвтрэх бүрд verify.mn (жинхэнэ SMS) ашиглан
    //    баталгаажуулна: хэрэглэгч бидний өгсөн кодыг 144773 руу SMS-ээр
    //    илгээснээр баталгаажина (sessionId-аар шалгана).
    Credentials({
      id: "phone",
      name: "Утасны дугаар",
      credentials: {
        phone: { label: "Утасны дугаар", type: "text" },
        code: { label: "Баталгаажуулах код", type: "text" },
        sessionId: { label: "Verify.mn session", type: "text" },
      },
      authorize: async (credentials) => {
        const phone = (credentials?.phone as string | undefined)?.trim();
        if (!phone) return null;

        const db = await getDb();
        const user = db.data.users.find((u) => u.phone === phone);
        if (!user) return null;
        if (user.banned) return null;

        const sessionId = (credentials?.sessionId as string | undefined)?.trim();
        if (sessionId) {
          // Жинхэнэ verify.mn SMS баталгаажуулалт: sessionId зөвхөн бидний
          // санах ойд ХАДГАЛСАН дугаартай холбогдсон эсэхийг шалгана (клиентээс
          // ирсэн "phone" талбарт итгэхгүй) — өөр хэн нэгний session-ийг өөр
          // дугаараар ашиглахаас сэргийлнэ.
          const boundPhone = getVerifySessionPhone(sessionId);
          if (!boundPhone || boundPhone !== phone) return null;

          let status;
          try {
            status = await getVerifySessionStatus(sessionId);
          } catch {
            return null;
          }
          if (status.sessionStatus !== "VERIFIED") return null;
          consumeVerifySession(sessionId);

          return {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          };
        }

        // Зөвхөн анхны удаагийн bootstrap кодод ашиглагдана.
        const code = (credentials?.code as string | undefined)?.trim();
        if (!code) return null;
        const ok = verifyOtp(phone, code);
        if (!ok) return null;

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
      },
    }),
  ],
});
