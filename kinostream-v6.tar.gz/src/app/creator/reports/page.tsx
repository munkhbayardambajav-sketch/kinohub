import { auth } from "@/auth";
import { buildCreatorReport, listCreators } from "@/lib/repo";
import FinanceReportTable from "@/components/FinanceReportTable";

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}
function firstOfMonthIso() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export default async function CreatorReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; creatorId?: string }>;
}) {
  const session = await auth();
  const { from, to, creatorId: creatorIdParam } = await searchParams;

  const isAdmin = session?.user?.role === "admin";
  const creators = isAdmin ? await listCreators() : [];
  const creatorId = isAdmin ? creatorIdParam || creators[0]?.id : session!.user!.id!;

  const fromDate = from || firstOfMonthIso();
  const toDate = to || todayIso();

  const report = creatorId
    ? await buildCreatorReport(creatorId, { from: fromDate, to: toDate })
    : null;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold">Санхүүгийн тайлан</h1>
      </div>

      <form className="card mb-6 flex flex-wrap items-end gap-3 p-4">
        {isAdmin && (
          <div>
            <label className="mb-1 block text-xs text-muted">Нийлүүлэгч</label>
            <select name="creatorId" defaultValue={creatorId} className="input">
              {creators.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        )}
        <div>
          <label className="mb-1 block text-xs text-muted">Эхлэл огноо</label>
          <input type="date" name="from" defaultValue={fromDate} className="input" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">Төгсгөл огноо</label>
          <input type="date" name="to" defaultValue={toDate} className="input" />
        </div>
        <button type="submit" className="btn-primary">
          Хайх
        </button>
      </form>

      {!report ? (
        <p className="text-muted">Нийлүүлэгч бүртгэгдээгүй байна.</p>
      ) : (
        <FinanceReportTable report={report} />
      )}
    </div>
  );
}
