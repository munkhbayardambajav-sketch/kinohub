import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";

export default async function CreatorLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (session?.user?.role !== "creator" && session?.user?.role !== "admin") {
    redirect("/login?callbackUrl=/creator/reports");
  }

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-[200px_1fr]">
      <aside className="card h-fit p-4">
        <p className="mb-3 text-sm font-semibold text-muted">Нийлүүлэгчийн самбар</p>
        <nav className="flex flex-col gap-1 text-sm">
          <Link href="/creator/reports" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Санхүүгийн тайлан
          </Link>
          <Link href="/" className="mt-3 rounded px-2 py-1.5 text-muted hover:bg-surface-2">
            ← Сайт руу буцах
          </Link>
        </nav>
      </aside>
      <section>{children}</section>
    </div>
  );
}
