import Link from "next/link";
import TitleCard from "@/components/TitleCard";
import { listTitles } from "@/lib/repo";

export default async function HomePage() {
  const [featured, movies, manga] = await Promise.all([
    listTitles({ featured: true }),
    listTitles({ type: "movie" }),
    listTitles({ type: "manga" }),
  ]);

  const hero = featured[0] ?? movies[0] ?? manga[0];

  return (
    <div className="space-y-10">
      {hero && (
        <section className="card relative overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={hero.backdrop || hero.poster}
            alt={hero.title}
            className="h-56 w-full object-cover opacity-40 sm:h-72"
          />
          <div className="absolute inset-0 flex flex-col justify-end gap-3 p-5 sm:p-8">
            <span className="w-fit rounded bg-accent px-2 py-1 text-xs font-semibold text-[#14110a]">
              Онцлох
            </span>
            <h1 className="max-w-2xl text-2xl font-bold sm:text-4xl">{hero.title}</h1>
            <p className="line-clamp-2 max-w-xl text-sm text-muted sm:text-base">
              {hero.description}
            </p>
            <Link href={`/title/${hero.slug}`} className="btn-primary w-fit">
              Дэлгэрэнгүй үзэх
            </Link>
          </div>
        </section>
      )}

      <TitleRow title="Шинэ кино" items={movies.slice(0, 12)} href="/browse/movie" />
      <TitleRow title="Шинэ манга" items={manga.slice(0, 12)} href="/browse/manga" />
    </div>
  );
}

function TitleRow({
  title,
  items,
  href,
}: {
  title: string;
  items: Awaited<ReturnType<typeof listTitles>>;
  href: string;
}) {
  if (items.length === 0) return null;
  return (
    <section>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">{title}</h2>
        <Link href={href} className="text-sm text-accent hover:underline">
          Бүгдийг үзэх →
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {items.map((t) => (
          <TitleCard key={t.id} title={t} />
        ))}
      </div>
    </section>
  );
}
