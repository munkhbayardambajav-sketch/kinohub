import Link from "next/link";
import { notFound } from "next/navigation";
import TitleCard from "@/components/TitleCard";
import { listCategories, listTitles } from "@/lib/repo";

export default async function BrowsePage({
  params,
  searchParams,
}: {
  params: Promise<{ type: string }>;
  searchParams: Promise<{ category?: string }>;
}) {
  const { type } = await params;
  const { category } = await searchParams;
  if (type !== "movie" && type !== "manga") notFound();

  const [titles, categories] = await Promise.all([
    listTitles({ type, categorySlug: category }),
    listCategories(),
  ]);

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-[200px_1fr]">
      <aside className="card h-fit p-4">
        <h2 className="mb-3 text-sm font-semibold text-muted">Ангилал</h2>
        <ul className="space-y-1 text-sm">
          <li>
            <Link
              href={`/browse/${type}`}
              className={`block rounded px-2 py-1 hover:bg-surface-2 ${!category ? "bg-surface-2 text-accent" : ""}`}
            >
              Бүгд
            </Link>
          </li>
          {categories.map((c) => (
            <li key={c.id}>
              <Link
                href={`/browse/${type}?category=${c.slug}`}
                className={`block rounded px-2 py-1 hover:bg-surface-2 ${category === c.slug ? "bg-surface-2 text-accent" : ""}`}
              >
                {c.name}
              </Link>
            </li>
          ))}
        </ul>
      </aside>

      <section>
        <h1 className="mb-4 text-xl font-bold">{type === "movie" ? "Кино" : "Манга"}</h1>
        {titles.length === 0 ? (
          <p className="text-muted">Одоогоор контент алга байна.</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {titles.map((t) => (
              <TitleCard key={t.id} title={t} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
