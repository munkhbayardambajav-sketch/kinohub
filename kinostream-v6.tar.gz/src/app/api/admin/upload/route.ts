import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import path from "path";
import fs from "fs/promises";
import { auth } from "@/auth";

export const runtime = "nodejs";

// Байршуулсан файлууд (постер, ар зураг, видео, манга хуудас) энд хадгалагдана.
// Серверт /public/uploads нь тусдаа, deploy-той хамт дарагдахгүй хавтас руу
// symlink хийгдсэн байх ёстой (README/тайлбарыг сервер дээрх тохиргооноос үзнэ үү).
const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

const MAX_IMAGE_BYTES = 20 * 1024 * 1024; // 20MB
const MAX_VIDEO_BYTES = 500 * 1024 * 1024; // 500MB

const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"]);
const VIDEO_TYPES = new Set([
  "video/mp4",
  "video/webm",
  "video/quicktime",
  "video/x-matroska",
  "video/x-msvideo",
]);

const EXT_FALLBACK: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "image/avif": ".avif",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
  "video/x-matroska": ".mkv",
  "video/x-msvideo": ".avi",
};

function sanitizeExt(name: string, mime: string): string {
  const ext = path.extname(name).toLowerCase();
  if (ext && /^\.[a-z0-9]{1,5}$/.test(ext)) return ext;
  return EXT_FALLBACK[mime] || "";
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (session?.user?.role !== "admin") {
    return NextResponse.json({ error: "Зөвшөөрөлгүй үйлдэл." }, { status: 403 });
  }

  let formData: FormData;
  try {
    formData = await req.formData();
  } catch {
    return NextResponse.json({ error: "Файл уншихад алдаа гарлаа." }, { status: 400 });
  }

  const file = formData.get("file");
  const kind = String(formData.get("kind") || "image");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Файл олдсонгүй." }, { status: 400 });
  }

  const isVideo = kind === "video";
  const allowedTypes = isVideo ? VIDEO_TYPES : IMAGE_TYPES;
  const maxBytes = isVideo ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;

  if (!allowedTypes.has(file.type)) {
    return NextResponse.json(
      { error: `Дэмжигдэхгүй файлын төрөл: ${file.type || "тодорхойгүй"}` },
      { status: 400 }
    );
  }
  if (file.size > maxBytes) {
    return NextResponse.json(
      { error: `Файл хэтэрхий том байна (дээд тал нь ${Math.round(maxBytes / 1024 / 1024)}MB).` },
      { status: 400 }
    );
  }

  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    const ext = sanitizeExt(file.name, file.type);
    const filename = `${randomUUID()}${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(path.join(UPLOAD_DIR, filename), buffer);
    return NextResponse.json({ url: `/uploads/${filename}` });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Файл хадгалахад алдаа гарлаа." },
      { status: 500 }
    );
  }
}
