import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getPurchaseById, markPurchasePaid } from "@/lib/repo";
import { checkPayment, isQpayReady } from "@/lib/qpay";

// Клиент энэ endpoint-ийг тогтмол polling хийж, төлбөр төлөгдсөн эсэхийг
// шалгана. Webhook callback ирээгүй/саатсан ч энд бид QPay-аас идэвхтэй
// шалгадаг тул найдвартай (webhook нь зөвхөн туслах хурдасгуур механизм).
export async function GET(request: Request) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Нэвтэрсэн байх шаардлагатай." }, { status: 401 });
  }

  const purchaseId = new URL(request.url).searchParams.get("purchaseId");
  if (!purchaseId) {
    return NextResponse.json({ error: "purchaseId шаардлагатай." }, { status: 400 });
  }

  const purchase = await getPurchaseById(purchaseId);
  if (!purchase || purchase.userId !== session.user.id) {
    return NextResponse.json({ error: "Олдсонгүй." }, { status: 404 });
  }

  if (purchase.status === "pending" && purchase.qpayInvoiceId && isQpayReady()) {
    try {
      const check = await checkPayment(purchase.qpayInvoiceId);
      const paidRow = check.rows?.find((r) => r.payment_status === "PAID");
      if (paidRow) {
        await markPurchasePaid(purchase.id, paidRow.payment_id);
        return NextResponse.json({ status: "paid" });
      }
    } catch {
      // QPay түр саатаж болно — статусыг өөрчлөхгүйгээр буцаана, клиент дараа дахин шалгана.
    }
  }

  return NextResponse.json({ status: purchase.status });
}
