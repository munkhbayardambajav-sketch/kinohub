import { NextResponse } from "next/server";
import { getPurchaseById, markPurchasePaid } from "@/lib/repo";
import { checkPayment, isQpayReady } from "@/lib/qpay";

// QPay энэ URL руу төлбөр амжилттай хийгдэх бүрт дуудна (callback_url).
// Аюулгүй байдлын үүднээс webhook-ийн агуулгад итгэлгүйгээр, QPay-аас
// /v2/payment/check-ээр давхар шалгаж баталгаажуулна.
async function handle(request: Request) {
  const url = new URL(request.url);
  const purchaseId = url.searchParams.get("purchaseId");
  if (!purchaseId) return NextResponse.json({ ok: false }, { status: 400 });

  const purchase = await getPurchaseById(purchaseId);
  if (!purchase) return NextResponse.json({ ok: false }, { status: 404 });

  if (purchase.status === "paid") return NextResponse.json({ ok: true });
  if (!purchase.qpayInvoiceId || !isQpayReady()) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  try {
    const check = await checkPayment(purchase.qpayInvoiceId);
    const paidRow = check.rows?.find((r) => r.payment_status === "PAID");
    if (paidRow) {
      await markPurchasePaid(purchase.id, paidRow.payment_id);
    }
  } catch {
    // QPay-тай холбогдож чадаагүй ч 200 буцаана — QPay дараа дахин callback дуудна,
    // мөн клиент талын /api/payments/status polling нөөц эх сурвалж болно.
  }

  return NextResponse.json({ ok: true });
}

export async function POST(request: Request) {
  return handle(request);
}

export async function GET(request: Request) {
  return handle(request);
}
