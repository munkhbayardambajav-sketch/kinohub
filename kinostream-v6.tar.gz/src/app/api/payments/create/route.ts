import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { createPendingPurchase, getTitleById, hasUserPurchased } from "@/lib/repo";
import { createInvoice, isQpayReady } from "@/lib/qpay";
import { getDb } from "@/lib/db";

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Нэвтэрсэн байх шаардлагатай." }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const titleId = body?.titleId as string | undefined;
  if (!titleId) {
    return NextResponse.json({ error: "titleId шаардлагатай." }, { status: 400 });
  }

  const title = await getTitleById(titleId);
  if (!title) {
    return NextResponse.json({ error: "Контент олдсонгүй." }, { status: 404 });
  }
  if (!title.price) {
    return NextResponse.json({ error: "Энэ контент үнэгүй байна." }, { status: 400 });
  }

  const already = await hasUserPurchased(titleId, session.user.id);
  if (already) {
    return NextResponse.json({ error: "Та энэ контентыг өмнө нь худалдаж авсан байна." }, { status: 400 });
  }

  if (!isQpayReady()) {
    return NextResponse.json(
      {
        error:
          "Төлбөрийн систем (QPay) одоогоор тохируулагдаагүй байна. Сайтын админтай холбогдоно уу.",
      },
      { status: 501 }
    );
  }

  const purchase = await createPendingPurchase({
    titleId,
    userId: session.user.id,
    creatorId: title.creatorId,
    price: title.price,
    method: "qpay",
  });

  const origin = new URL(request.url).origin;
  const callbackUrl = `${origin}/api/payments/qpay/callback?purchaseId=${purchase.id}`;

  try {
    const invoice = await createInvoice({
      amount: title.price,
      description: `${title.title} — ${title.type === "movie" ? "кино" : "манга"}`,
      senderInvoiceNo: purchase.id,
      callbackUrl,
    });

    // qpayInvoiceId-г бүртгэлд хадгална (дараа нь status шалгахад ашиглана)
    const db = await getDb();
    const p = db.data.purchases.find((x) => x.id === purchase.id);
    if (p) {
      p.qpayInvoiceId = invoice.invoice_id;
      await db.write();
    }

    return NextResponse.json({
      purchaseId: purchase.id,
      invoiceId: invoice.invoice_id,
      qrImage: invoice.qr_image,
      qrText: invoice.qr_text,
      urls: invoice.urls || [],
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "QPay нэхэмжлэл үүсгэхэд алдаа гарлаа." },
      { status: 502 }
    );
  }
}
