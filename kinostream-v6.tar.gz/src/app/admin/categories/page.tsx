import { listCategories } from "@/lib/repo";
import { createCategoryAction, deleteCategoryAction, updateCategoryAction } from "@/lib/actions/admin";

export default async function AdminCategoriesPage() {
  const categories = await listCategories();

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Ангилал</h1>

      <form action={createCategoryAction} className="card flex gap-2 p-4">
        <input name="name" required placeholder="Шинэ ангиллын нэр" className="input flex-1" />
        <button type="submit" className="btn-primary">
          Нэмэх
        </button>
      </form>

      <div className="card divide-y divide-border">
        {categories.map((c) => (
          <div key={c.id} className="flex items-center gap-3 p-3">
            <form action={updateCategoryAction} className="flex flex-1 gap-2">
              <input type="hidden" name="id" value={c.id} />
              <input name="name" defaultValue={c.name} className="input flex-1" />
              <button type="submit" className="btn-secondary text-sm">
                Хадгалах
              </button>
            </form>
            <form action={deleteCategoryAction}>
              <input type="hidden" name="id" value={c.id} />
              <button type="submit" className="btn-secondary text-sm text-accent-2">
                Устгах
              </button>
            </form>
          </div>
        ))}
        {categories.length === 0 && <p className="p-4 text-muted">Ангилал алга байна.</p>}
      </div>
    </div>
  );
}
