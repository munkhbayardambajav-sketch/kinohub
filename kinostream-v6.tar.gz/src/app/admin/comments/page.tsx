import { listAllComments, listTitles } from "@/lib/repo";
import { deleteCommentAdminAction } from "@/lib/actions/admin";

export default async function AdminCommentsPage() {
  const [comments, titles] = await Promise.all([listAllComments(), listTitles()]);
  const titleById = new Map(titles.map((t) => [t.id, t]));

  return (
    <div>
      <h1 className="mb-4 text-xl font-bold">Сэтгэгдэл ({comments.length})</h1>
      <div className="card divide-y divide-border">
        {comments.map((c) => {
          const t = titleById.get(c.titleId);
          return (
            <div key={c.id} className="flex items-start gap-3 p-3 text-sm">
              <div className="flex-1">
                <p className="text-xs text-muted">
                  {c.userName} · {t?.title || "Устгагдсан контент"} ·{" "}
                  {new Date(c.createdAt).toLocaleString("mn-MN")}
                </p>
                <p className="mt-1">{c.text}</p>
              </div>
              <form action={deleteCommentAdminAction}>
                <input type="hidden" name="id" value={c.id} />
                <button type="submit" className="btn-secondary text-xs text-accent-2">
                  Устгах
                </button>
              </form>
            </div>
          );
        })}
        {comments.length === 0 && <p className="p-4 text-muted">Сэтгэгдэл алга байна.</p>}
      </div>
    </div>
  );
}
