import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (session?.user?.role !== "admin") {
    redirect("/login?callbackUrl=/admin");
  }

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-[200px_1fr]">
      <aside className="card h-fit p-4">
        <p className="mb-3 text-sm font-semibold text-muted">Админ панел</p>
        <nav className="flex flex-col gap-1 text-sm">
          <Link href="/admin" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Хянах самбар
          </Link>
          <Link href="/admin/titles" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Контент (кино/манга)
          </Link>
          <Link href="/admin/categories" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Ангилал
          </Link>
          <Link href="/admin/users" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Хэрэглэгчид
          </Link>
          <Link href="/admin/purchases" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Худалдан авалт
          </Link>
          <Link href="/admin/finance" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Санхүүгийн тайлан
          </Link>
          <Link href="/admin/comments" className="rounded px-2 py-1.5 hover:bg-surface-2">
            Сэтгэгдэл
          </Link>
          <Link href="/" className="mt-3 rounded px-2 py-1.5 text-muted hover:bg-surface-2">
            ← Сайт руу буцах
          </Link>
        </nav>
      </aside>
      <section>{children}</section>
    </div>
  );
}
