import { notFound } from "next/navigation";
import { getTitleById, listCategories, listCreators } from "@/lib/repo";
import { updateTitleAction } from "@/lib/actions/admin";
import TitleForm from "../../TitleForm";

export default async function EditTitlePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const [title, categories, creators] = await Promise.all([
    getTitleById(id),
    listCategories(),
    listCreators(),
  ]);
  if (!title) notFound();

  return (
    <div>
      <h1 className="mb-4 text-xl font-bold">Контент засах</h1>
      <TitleForm categories={categories} creators={creators} initial={title} action={updateTitleAction} />
    </div>
  );
}
