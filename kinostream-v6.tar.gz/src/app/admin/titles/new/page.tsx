import { listCategories, listCreators } from "@/lib/repo";
import { createTitleAction } from "@/lib/actions/admin";
import TitleForm from "../TitleForm";

export default async function NewTitlePage() {
  const [categories, creators] = await Promise.all([listCategories(), listCreators()]);
  return (
    <div>
      <h1 className="mb-4 text-xl font-bold">Шинэ контент нэмэх</h1>
      <TitleForm categories={categories} creators={creators} action={createTitleAction} />
    </div>
  );
}
