"use client";

import { useRef, useState } from "react";
import type { Category, ContentType, MangaChapter, Title, User } from "@/lib/types";

type ActionFn = (formData: FormData) => void | Promise<void>;

async function uploadFile(file: File, kind: "image" | "video"): Promise<string> {
  const body = new FormData();
  body.append("file", file);
  body.append("kind", kind);
  const res = await fetch("/api/admin/upload", { method: "POST", body });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || "Байршуулахад алдаа гарлаа.");
  }
  return data.url as string;
}

function UploadField({
  label,
  kind,
  value,
  onChange,
  required,
}: {
  label: string;
  kind: "image" | "video";
  value: string;
  onChange: (url: string) => void;
  required?: boolean;
}) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(undefined);
    try {
      const url = await uploadFile(file, kind);
      onChange(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Байршуулахад алдаа гарлаа.");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div>
      <label className="mb-1 block text-sm text-muted">
        {label}
        {required && !value && <span className="text-accent-2"> *</span>}
      </label>
      <div className="flex items-center gap-2">
        <input
          ref={inputRef}
          type="file"
          accept={kind === "video" ? "video/*" : "image/*"}
          onChange={handleFile}
          disabled={uploading}
          className="input w-full text-xs file:mr-2 file:rounded file:border-0 file:bg-accent file:px-2 file:py-1 file:text-xs file:font-medium file:text-[#14110a]"
        />
        {uploading && <span className="shrink-0 text-xs text-muted">Хуулж байна...</span>}
      </div>
      {error && <p className="mt-1 text-xs text-accent-2">{error}</p>}
      {value && kind === "image" && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={value} alt="" className="mt-2 h-24 w-auto rounded border border-border object-cover" />
      )}
      {value && kind === "video" && (
        <p className="mt-1 truncate text-xs text-muted">✓ {value}</p>
      )}
      <details className="mt-1">
        <summary className="cursor-pointer text-xs text-muted hover:text-foreground">
          эсвэл URL шууд оруулах
        </summary>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://..."
          className="input mt-1 w-full text-xs"
        />
      </details>
    </div>
  );
}

export default function TitleForm({
  categories,
  creators,
  initial,
  action,
}: {
  categories: Category[];
  creators: User[];
  initial?: Title;
  action: ActionFn;
}) {
  const [type, setType] = useState<ContentType>(initial?.type || "movie");
  const [chapters, setChapters] = useState<MangaChapter[]>(initial?.chapters || []);
  const [poster, setPoster] = useState(initial?.poster || "");
  const [backdrop, setBackdrop] = useState(initial?.backdrop || "");
  const [videoUrl, setVideoUrl] = useState(initial?.videoUrl || "");

  function addChapter() {
    setChapters((prev) => [
      ...prev,
      { id: crypto.randomUUID(), number: prev.length + 1, title: "", images: [] },
    ]);
  }

  function updateChapter(id: string, patch: Partial<MangaChapter>) {
    setChapters((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }

  function removeChapter(id: string) {
    setChapters((prev) => prev.filter((c) => c.id !== id));
  }

  async function handleChapterFiles(id: string, files: FileList | null) {
    if (!files || files.length === 0) return;
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      try {
        urls.push(await uploadFile(file, "image"));
      } catch {
        // тухайн файлыг алгасаад үргэлжлүүлнэ
      }
    }
    if (urls.length) {
      setChapters((prev) =>
        prev.map((c) => (c.id === id ? { ...c, images: [...c.images, ...urls] } : c))
      );
    }
  }

  return (
    <form action={action} className="card space-y-4 p-5">
      {initial && <input type="hidden" name="id" value={initial.id} />}
      <input type="hidden" name="chaptersJson" value={JSON.stringify(chapters)} />
      <input type="hidden" name="poster" value={poster} />
      <input type="hidden" name="backdrop" value={backdrop} />
      {type === "movie" && <input type="hidden" name="videoUrl" value={videoUrl} />}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-muted">Төрөл</label>
          <select
            name="type"
            value={type}
            onChange={(e) => setType(e.target.value as ContentType)}
            className="input w-full"
          >
            <option value="movie">Кино</option>
            <option value="manga">Манга</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm text-muted">Огноо (жил)</label>
          <input name="year" type="number" defaultValue={initial?.year} className="input w-full" />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Гарчиг</label>
        <input name="title" required defaultValue={initial?.title} className="input w-full" />
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Тайлбар</label>
        <textarea
          name="description"
          required
          rows={4}
          defaultValue={initial?.description}
          className="input w-full"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <UploadField label="Постер зураг" kind="image" value={poster} onChange={setPoster} required />
        <UploadField label="Ар зураг (заавал биш)" kind="image" value={backdrop} onChange={setBackdrop} />
      </div>

      <div>
        <label className="mb-1 block text-sm text-muted">Улс (заавал биш)</label>
        <input name="country" defaultValue={initial?.country} className="input w-full" />
      </div>

      <div>
        <label className="mb-2 block text-sm text-muted">Ангилал</label>
        <div className="flex flex-wrap gap-3 text-sm">
          {categories.map((c) => (
            <label key={c.id} className="flex items-center gap-1.5">
              <input
                type="checkbox"
                name="categoryIds"
                value={c.id}
                defaultChecked={initial?.categoryIds.includes(c.id)}
              />
              {c.name}
            </label>
          ))}
        </div>
      </div>

      <div className="flex gap-6 text-sm">
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="featured" defaultChecked={initial?.featured} />
          Онцлох
        </label>
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="ageRestricted" defaultChecked={initial?.ageRestricted} />
          18+
        </label>
      </div>

      <div className="rounded border border-border p-3">
        <p className="mb-2 text-sm font-semibold text-muted">Төлбөр / Нийлүүлэгч</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-sm text-muted">
              Үнэ (₮) — хоосон/0 бол үнэгүй
            </label>
            <input
              name="price"
              type="number"
              min={0}
              step={100}
              defaultValue={initial?.price}
              className="input w-full"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm text-muted">Нийлүүлэгч (эзэмшигч)</label>
            <select name="creatorId" defaultValue={initial?.creatorId || ""} className="input w-full">
              <option value="">— Манай платформын контент —</option>
              {creators.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.email ?? c.phone ?? "—"})
                </option>
              ))}
            </select>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted">
          Үнэтэй бол тухайн нийлүүлэгч /creator дотор энэ контентын үзэлт, орлого, санхүүгийн
          тайлангаа харна. Хуваарилалт: манай компани 40%, нийлүүлэгч 60% (НӨАТ хассаны дараа).
        </p>
      </div>

      {type === "movie" ? (
        <UploadField label="Видео файл" kind="video" value={videoUrl} onChange={setVideoUrl} required />
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm text-muted">Бүлгүүд (манга)</label>
            <button type="button" onClick={addChapter} className="btn-secondary text-xs">
              + Бүлэг нэмэх
            </button>
          </div>
          {chapters.map((c) => (
            <div key={c.id} className="rounded border border-border p-3">
              <div className="mb-2 flex items-center gap-2">
                <input
                  type="number"
                  value={c.number}
                  onChange={(e) => updateChapter(c.id, { number: Number(e.target.value) })}
                  className="input w-20"
                />
                <input
                  value={c.title}
                  onChange={(e) => updateChapter(c.id, { title: e.target.value })}
                  placeholder="Бүлгийн нэр"
                  className="input flex-1"
                />
                <button
                  type="button"
                  onClick={() => removeChapter(c.id)}
                  className="btn-secondary text-xs text-accent-2"
                >
                  Устгах
                </button>
              </div>

              <div className="mb-2">
                <label className="mb-1 block text-xs text-muted">
                  Хуудасны зурагнууд компьютерээс сонгох (олноор сонгож болно)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(e) => handleChapterFiles(c.id, e.target.files)}
                  className="input w-full text-xs file:mr-2 file:rounded file:border-0 file:bg-accent file:px-2 file:py-1 file:text-xs file:font-medium file:text-[#14110a]"
                />
                <p className="mt-1 text-xs text-muted">
                  {c.images.length} зураг байршуулагдсан. Дараалал/жагсаалтыг доор гараар засаж болно.
                </p>
              </div>

              <textarea
                placeholder="Хуудасны зургийн URL (мөр бүрт нэг)"
                value={c.images.join("\n")}
                onChange={(e) =>
                  updateChapter(c.id, {
                    images: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean),
                  })
                }
                rows={3}
                className="input w-full text-xs"
              />
            </div>
          ))}
        </div>
      )}

      <button type="submit" className="btn-primary">
        Хадгалах
      </button>
    </form>
  );
}
