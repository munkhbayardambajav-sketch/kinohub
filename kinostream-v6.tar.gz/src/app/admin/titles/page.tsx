import Link from "next/link";
import { listTitles, listCreators } from "@/lib/repo";
import { deleteTitleAction } from "@/lib/actions/admin";
import { formatMnt } from "@/lib/finance";

export default async function AdminTitlesPage() {
  const [titles, creators] = await Promise.all([listTitles(), listCreators()]);
  const creatorById = new Map(creators.map((c) => [c.id, c]));

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">Контент</h1>
        <Link href="/admin/titles/new" className="btn-primary text-sm">
          + Шинэ нэмэх
        </Link>
      </div>

      <div className="card divide-y divide-border">
        {titles.map((t) => (
          <div key={t.id} className="flex items-center gap-3 p-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={t.poster} alt={t.title} className="h-16 w-12 rounded object-cover" />
            <div className="flex-1">
              <p className="font-medium">{t.title}</p>
              <p className="text-xs text-muted">
                {t.type === "movie" ? "Кино" : "Манга"} · {t.views} үзэлт
                {t.price ? ` · ${formatMnt(t.price)}₮` : " · Үнэгүй"}
                {t.creatorId && creatorById.get(t.creatorId)
                  ? ` · ${creatorById.get(t.creatorId)!.name}`
                  : ""}
              </p>
            </div>
            <Link href={`/admin/titles/${t.id}/edit`} className="btn-secondary text-sm">
              Засах
            </Link>
            <form action={deleteTitleAction}>
              <input type="hidden" name="id" value={t.id} />
              <button
                type="submit"
                className="btn-secondary text-sm text-accent-2"
              >
                Устгах
              </button>
            </form>
          </div>
        ))}
        {titles.length === 0 && <p className="p-4 text-muted">Контент алга байна.</p>}
      </div>
    </div>
  );
}
