"use client";

import { useTransition } from "react";
import { setUserRoleAction } from "@/lib/actions/admin";
import type { Role } from "@/lib/types";

export default function RoleSelect({
  userId,
  role,
  disabled,
}: {
  userId: string;
  role: Role;
  disabled?: boolean;
}) {
  const [pending, startTransition] = useTransition();

  return (
    <select
      defaultValue={role}
      disabled={disabled || pending}
      onChange={(e) => {
        const fd = new FormData();
        fd.set("id", userId);
        fd.set("role", e.target.value);
        startTransition(() => {
          setUserRoleAction(fd);
        });
      }}
      className="input text-xs"
    >
      <option value="user">Хэрэглэгч</option>
      <option value="creator">Нийлүүлэгч</option>
      <option value="admin">Админ</option>
    </select>
  );
}
