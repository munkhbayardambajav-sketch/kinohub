"use client";

import { useActionState } from "react";
import { adminCreateUserAction } from "@/lib/actions/admin";

export default function CreateUserForm() {
  const [state, formAction, pending] = useActionState(adminCreateUserAction, undefined);

  return (
    <form action={formAction} className="card grid grid-cols-1 gap-3 p-4 sm:grid-cols-5">
      <input name="name" required placeholder="Нэр" className="input" />
      <input name="email" type="email" required placeholder="Имэйл" className="input" />
      <input
        name="password"
        type="password"
        required
        minLength={6}
        placeholder="Нууц үг"
        className="input"
      />
      <select name="role" defaultValue="creator" className="input">
        <option value="creator">Нийлүүлэгч</option>
        <option value="user">Хэрэглэгч</option>
        <option value="admin">Админ</option>
      </select>
      <button type="submit" disabled={pending} className="btn-primary">
        {pending ? "..." : "Нэмэх"}
      </button>
      {state?.error && (
        <p className="sm:col-span-5 text-sm text-accent-2">{state.error}</p>
      )}
    </form>
  );
}
