import { getStats } from "@/lib/repo";
import { formatMnt } from "@/lib/finance";

export default async function AdminDashboard() {
  const stats = await getStats();

  const cards = [
    { label: "Нийт хэрэглэгч", value: stats.totalUsers },
    { label: "Нийлүүлэгч", value: stats.totalCreators },
    { label: "Нийт контент", value: stats.totalTitles },
    { label: "Кино", value: stats.totalMovies },
    { label: "Манга", value: stats.totalManga },
    { label: "Нийт сэтгэгдэл", value: stats.totalComments },
    { label: "Нийт үзэлт", value: stats.totalViews },
    { label: "Нийт худалдан авалт", value: stats.totalSales },
    { label: "Манай орлого (40%)", value: `${formatMnt(stats.totalPlatformRevenue)}₮` },
    { label: "Нийлүүлэгчдэд өгсөн (60%)", value: `${formatMnt(stats.totalCreatorPayouts)}₮` },
  ];

  return (
    <div>
      <h1 className="mb-4 text-xl font-bold">Хянах самбар</h1>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="card p-4">
            <p className="text-2xl font-bold text-accent">{c.value}</p>
            <p className="text-sm text-muted">{c.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
