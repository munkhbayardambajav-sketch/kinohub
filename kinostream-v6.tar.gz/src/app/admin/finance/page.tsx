import { buildPlatformReport } from "@/lib/repo";
import FinanceReportTable from "@/components/FinanceReportTable";

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}
function firstOfMonthIso() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export default async function AdminFinancePage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string }>;
}) {
  const { from, to } = await searchParams;
  const fromDate = from || firstOfMonthIso();
  const toDate = to || todayIso();

  const report = await buildPlatformReport({ from: fromDate, to: toDate });

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">Санхүүгийн тайлан (платформ даяар)</h1>
        <a href="/admin/purchases" className="text-sm text-accent hover:underline">
          Худалдан авалтууд →
        </a>
      </div>

      <form className="card mb-6 flex flex-wrap items-end gap-3 p-4">
        <div>
          <label className="mb-1 block text-xs text-muted">Эхлэл огноо</label>
          <input type="date" name="from" defaultValue={fromDate} className="input" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted">Төгсгөл огноо</label>
          <input type="date" name="to" defaultValue={toDate} className="input" />
        </div>
        <button type="submit" className="btn-primary">
          Хайх
        </button>
      </form>

      <p className="mb-3 text-xs text-muted">
        Энэ тайланд манай платформын нийт үнэтэй контентын (нийлүүлэгчтэй болон
        манайхаа шууд байршуулсан) орлого багтсан. Тодорхой нэг нийлүүлэгчид
        зориулсан тайланг Хэрэглэгчид хэсгээс тухайн хүнийг нийлүүлэгч болгосны
        дараа <a href="/creator/reports" className="text-accent hover:underline">энд</a>{" "}
        нийлүүлэгчээр шүүж харна уу.
      </p>

      <FinanceReportTable report={report} />
    </div>
  );
}
