"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { formatMnt } from "@/lib/finance";

interface InvoiceState {
  purchaseId: string;
  qrImage: string;
  qrText: string;
  urls: { name: string; description: string; link: string }[];
}

export default function BuyButton({ titleId, price }: { titleId: string; price: number }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [invoice, setInvoice] = useState<InvoiceState | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  async function startPurchase() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/payments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titleId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Алдаа гарлаа.");
        setLoading(false);
        return;
      }
      setInvoice(data);
      pollRef.current = setInterval(async () => {
        const s = await fetch(`/api/payments/status?purchaseId=${data.purchaseId}`);
        const sd = await s.json();
        if (sd.status === "paid") {
          if (pollRef.current) clearInterval(pollRef.current);
          router.refresh();
        }
      }, 3000);
    } catch {
      setError("Сүлжээний алдаа гарлаа.");
    } finally {
      setLoading(false);
    }
  }

  if (invoice) {
    return (
      <div className="card space-y-3 p-5">
        <p className="text-sm text-muted">
          QPay апп-аараа доорх QR кодыг уншуулж төлбөрөө төлнө үү. Төлбөр
          баталгаажмагц хуудас автоматаар шинэчлэгдэнэ.
        </p>
        {invoice.qrImage && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={`data:image/png;base64,${invoice.qrImage}`}
            alt="QPay QR"
            className="mx-auto h-56 w-56 rounded bg-white p-2"
          />
        )}
        {invoice.urls?.length > 0 && (
          <div className="flex flex-wrap justify-center gap-2">
            {invoice.urls.map((u) => (
              <a key={u.name} href={u.link} className="btn-secondary text-xs">
                {u.description}
              </a>
            ))}
          </div>
        )}
        <p className="text-center text-xs text-muted">Төлбөр хүлээгдэж байна...</p>
      </div>
    );
  }

  return (
    <div className="card space-y-3 p-5">
      <p className="text-sm text-muted">Энэ контентыг үзэхийн тулд худалдаж авах шаардлагатай.</p>
      <button onClick={startPurchase} disabled={loading} className="btn-primary">
        {loading ? "Түр хүлээнэ үү..." : `Худалдаж авах — ${formatMnt(price)}₮`}
      </button>
      {error && <p className="text-sm text-accent-2">{error}</p>}
    </div>
  );
}
