"use client";

import { useRef } from "react";
import { addCommentAction } from "@/lib/actions/comments";

export default function CommentForm({ titleId }: { titleId: string }) {
  const formRef = useRef<HTMLFormElement>(null);

  return (
    <form
      ref={formRef}
      action={async (formData) => {
        await addCommentAction(formData);
        formRef.current?.reset();
      }}
      className="flex gap-2"
    >
      <input type="hidden" name="titleId" value={titleId} />
      <input
        name="text"
        required
        placeholder="Сэтгэгдэл бичих..."
        className="input flex-1"
        maxLength={1000}
      />
      <button type="submit" className="btn-primary">
        Илгээх
      </button>
    </form>
  );
}
