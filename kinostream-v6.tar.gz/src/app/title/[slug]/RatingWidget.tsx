"use client";

import { useState, useTransition } from "react";
import { rateAction } from "@/lib/actions/ratings";

export default function RatingWidget({
  titleId,
  initialValue,
  loggedIn,
}: {
  titleId: string;
  initialValue: number | null;
  loggedIn: boolean;
}) {
  const [value, setValue] = useState(initialValue || 0);
  const [pending, startTransition] = useTransition();

  if (!loggedIn) {
    return (
      <p className="text-sm text-muted">
        Үнэлгээ өгөхийн тулд{" "}
        <a href="/login" className="text-accent hover:underline">
          нэвтэрнэ үү
        </a>
        .
      </p>
    );
  }

  return (
    <div className="flex items-center gap-1">
      <span className="mr-2 text-sm text-muted">Таны үнэлгээ:</span>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          disabled={pending}
          onClick={() => {
            setValue(n);
            const fd = new FormData();
            fd.set("titleId", titleId);
            fd.set("value", String(n));
            startTransition(() => {
              rateAction(fd);
            });
          }}
          className={`text-xl ${n <= value ? "text-accent" : "text-muted"}`}
          aria-label={`${n} од`}
        >
          ★
        </button>
      ))}
    </div>
  );
}
