import { notFound } from "next/navigation";
import { auth } from "@/auth";
import {
  getTitleBySlug,
  incrementViews,
  listCategories,
  listCommentsForTitle,
  getRatingStats,
  getUserRating,
  hasUserPurchased,
} from "@/lib/repo";
import { formatMnt } from "@/lib/finance";
import MangaReader from "./MangaReader";
import CommentForm from "./CommentForm";
import RatingWidget from "./RatingWidget";
import BuyButton from "./BuyButton";

export default async function TitleDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const title = await getTitleBySlug(slug);
  if (!title) notFound();

  await incrementViews(title.id);

  const [session, categories, comments, ratingStats] = await Promise.all([
    auth(),
    listCategories(),
    listCommentsForTitle(title.id),
    getRatingStats(title.id),
  ]);

  const userRating = session?.user?.id
    ? await getUserRating(title.id, session.user.id)
    : null;

  const cats = categories.filter((c) => title.categoryIds.includes(c.id));

  const isPaid = !!title.price;
  const isOwnerOrAdmin =
    session?.user?.role === "admin" ||
    (session?.user?.role === "creator" && session.user.id === title.creatorId);
  const hasPurchased =
    isPaid && !isOwnerOrAdmin && session?.user?.id
      ? await hasUserPurchased(title.id, session.user.id)
      : false;
  const hasAccess = !isPaid || isOwnerOrAdmin || hasPurchased;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-[240px_1fr]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={title.poster} alt={title.title} className="poster" />
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">{title.title}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-muted">
            <span className="rounded bg-surface-2 px-2 py-0.5">
              {title.type === "movie" ? "Кино" : "Манга"}
            </span>
            {title.year && <span>{title.year}</span>}
            {title.ageRestricted && (
              <span className="rounded bg-accent-2/20 px-2 py-0.5 text-accent-2">18+</span>
            )}
            <span>👁 {title.views} үзсэн</span>
            {isPaid && (
              <span className="rounded bg-accent/20 px-2 py-0.5 text-accent">
                {formatMnt(title.price!)}₮
              </span>
            )}
            {ratingStats.count > 0 && (
              <span>
                ⭐ {ratingStats.avg} ({ratingStats.count})
              </span>
            )}
            {cats.map((c) => (
              <span key={c.id} className="rounded bg-surface-2 px-2 py-0.5">
                {c.name}
              </span>
            ))}
          </div>
          <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-foreground/90">
            {title.description}
          </p>

          <div className="mt-4">
            <RatingWidget titleId={title.id} initialValue={userRating} loggedIn={!!session?.user} />
          </div>
        </div>
      </div>

      {!hasAccess ? (
        session?.user ? (
          <BuyButton titleId={title.id} price={title.price!} />
        ) : (
          <div className="card p-5 text-sm text-muted">
            Энэ контентыг худалдаж авахын тулд{" "}
            <a href={`/login?callbackUrl=/title/${title.slug}`} className="text-accent hover:underline">
              нэвтэрнэ үү
            </a>
            .
          </div>
        )
      ) : title.type === "movie" ? (
        <section className="card overflow-hidden">
          {title.videoUrl ? (

            <video controls className="w-full bg-black" src={title.videoUrl} poster={title.backdrop} />
          ) : (
            <p className="p-6 text-muted">Видео линк одоогоор нэмэгдээгүй байна.</p>
          )}
        </section>
      ) : (
        <MangaReader chapters={title.chapters || []} />
      )}

      <section>
        <h2 className="mb-3 text-lg font-semibold">Сэтгэгдэл ({comments.length})</h2>
        {session?.user ? (
          <CommentForm titleId={title.id} />
        ) : (
          <p className="mb-4 text-sm text-muted">
            Сэтгэгдэл бичихийн тулд{" "}
            <a href="/login" className="text-accent hover:underline">
              нэвтэрнэ үү
            </a>
            .
          </p>
        )}
        <ul className="mt-4 space-y-3">
          {comments.map((c) => (
            <li key={c.id} className="card p-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium">{c.userName}</span>
                <span className="text-xs text-muted">
                  {new Date(c.createdAt).toLocaleString("mn-MN")}
                </span>
              </div>
              <p className="mt-1 text-foreground/90">{c.text}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
