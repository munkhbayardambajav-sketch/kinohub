"use client";

import { useState } from "react";
import type { MangaChapter } from "@/lib/types";

export default function MangaReader({ chapters }: { chapters: MangaChapter[] }) {
  const [activeId, setActiveId] = useState(chapters[0]?.id);
  const active = chapters.find((c) => c.id === activeId);

  if (chapters.length === 0) {
    return <p className="text-muted">Бүлэг одоогоор нэмэгдээгүй байна.</p>;
  }

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {chapters
          .slice()
          .sort((a, b) => a.number - b.number)
          .map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveId(c.id)}
              className={c.id === activeId ? "btn-primary text-sm" : "btn-secondary text-sm"}
            >
              {c.number}-р бүлэг
            </button>
          ))}
      </div>

      {active && (
        <div className="card space-y-2 p-3">
          <h3 className="font-semibold">{active.title}</h3>
          <div className="flex flex-col items-center gap-2">
            {active.images.map((src, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img key={i} src={src} alt={`${active.title} - ${i + 1}`} className="max-w-full rounded" />
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
