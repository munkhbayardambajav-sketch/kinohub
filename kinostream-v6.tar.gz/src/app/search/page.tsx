import TitleCard from "@/components/TitleCard";
import { listTitles } from "@/lib/repo";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const titles = q ? await listTitles({ q }) : [];

  return (
    <div>
      <h1 className="mb-4 text-xl font-bold">
        Хайлтын үр дүн: <span className="text-accent">&quot;{q}&quot;</span>
      </h1>
      {titles.length === 0 ? (
        <p className="text-muted">Илэрц олдсонгүй.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {titles.map((t) => (
            <TitleCard key={t.id} title={t} />
          ))}
        </div>
      )}
    </div>
  );
}
