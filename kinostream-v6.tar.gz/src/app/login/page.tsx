import LoginForm from "./LoginForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>;
}) {
  const { callbackUrl } = await searchParams;

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Нэвтрэх</h1>
      <LoginForm callbackUrl={callbackUrl || "/"} />
      <p className="mt-4 text-sm text-muted">
        Утасны дугаараа оруулаад шууд нэвтэрнэ үү — анхны удаа бол бүртгэл
        автоматаар үүснэ.
      </p>
      <p className="mt-2 text-sm text-muted">
        Админ/нийлүүлэгч эрхтэй юу?{" "}
        <a href="/login/staff" className="text-accent hover:underline">
          Имэйлээр нэвтрэх
        </a>
      </p>
    </div>
  );
}
