"use client";

import { useActionState } from "react";
import { loginAction } from "@/lib/actions/account";

export default function StaffLoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [state, formAction, pending] = useActionState(loginAction, undefined);

  return (
    <form action={formAction} className="card space-y-3 p-5">
      <input type="hidden" name="callbackUrl" value={callbackUrl} />
      <div>
        <label className="mb-1 block text-sm text-muted">Имэйл</label>
        <input name="email" type="email" required className="input w-full" />
      </div>
      <div>
        <label className="mb-1 block text-sm text-muted">Нууц үг</label>
        <input name="password" type="password" required className="input w-full" />
      </div>
      {state?.error && <p className="text-sm text-accent-2">{state.error}</p>}
      <button type="submit" disabled={pending} className="btn-primary w-full">
        {pending ? "Түр хүлээнэ үү..." : "Нэвтрэх"}
      </button>
    </form>
  );
}
