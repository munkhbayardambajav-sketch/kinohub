import StaffLoginForm from "./StaffLoginForm";

export default async function StaffLoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>;
}) {
  const { callbackUrl } = await searchParams;

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Ажилтны нэвтрэх</h1>
      <StaffLoginForm callbackUrl={callbackUrl || "/"} />
      <p className="mt-4 text-sm text-muted">
        Энгийн хэрэглэгч үү?{" "}
        <a href="/login" className="text-accent hover:underline">
          Утасны дугаараар нэвтрэх
        </a>
      </p>
    </div>
  );
}
