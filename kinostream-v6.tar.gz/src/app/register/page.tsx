import RegisterForm from "./RegisterForm";

export default function RegisterPage() {
  return (
    <div className="mx-auto max-w-sm">
      <h1 className="mb-6 text-2xl font-bold">Бүртгүүлэх</h1>
      <RegisterForm />
      <p className="mt-4 text-sm text-muted">
        Хаягтай юу?{" "}
        <a href="/login" className="text-accent hover:underline">
          Нэвтрэх
        </a>
      </p>
    </div>
  );
}
