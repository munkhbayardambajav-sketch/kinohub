"use client";

import { useActionState } from "react";
import { registerAction } from "@/lib/actions/account";

export default function RegisterForm() {
  const [state, formAction, pending] = useActionState(registerAction, undefined);

  return (
    <form action={formAction} className="card space-y-3 p-5">
      <div>
        <label className="mb-1 block text-sm text-muted">Нэр</label>
        <input name="name" required className="input w-full" />
      </div>
      <div>
        <label className="mb-1 block text-sm text-muted">Имэйл</label>
        <input name="email" type="email" required className="input w-full" />
      </div>
      <div>
        <label className="mb-1 block text-sm text-muted">Нууц үг</label>
        <input name="password" type="password" required minLength={6} className="input w-full" />
      </div>
      {state?.error && <p className="text-sm text-accent-2">{state.error}</p>}
      <button type="submit" disabled={pending} className="btn-primary w-full">
        {pending ? "Түр хүлээнэ үү..." : "Бүртгүүлэх"}
      </button>
    </form>
  );
}
