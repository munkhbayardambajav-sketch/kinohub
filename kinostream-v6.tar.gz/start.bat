@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo == MediaHub -- локал тест орчин бэлдэж байна ==

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo АЛДАА: Node.js суусан олдсонгүй.
  echo Эхлээд https://nodejs.org хаягаас Node.js 20 буюу түүнээс дээш хувилбарыг суулгаад дахин ажиллуулна уу.
  pause
  exit /b 1
)

if not exist node_modules (
  echo.
  echo -- Шаардлагатай сангуудыг суулгаж байна (npm install)... энэ хэсэг хэдэн минут үргэлжилж болно --
  call npm install
  if errorlevel 1 (
    echo npm install амжилтгүй боллоо.
    pause
    exit /b 1
  )
)

if not exist .env.local (
  echo.
  echo -- .env.local үүсгэж, нууц түлхүүр (AUTH_SECRET) автоматаар үүсгэж байна --
  copy .env.example .env.local >nul
  for /f "delims=" %%S in ('node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"') do set SECRET=%%S
  powershell -NoProfile -Command "(Get-Content .env.local) -replace '^AUTH_SECRET=.*', 'AUTH_SECRET=%SECRET%' | Set-Content .env.local"
)

echo.
echo ======================================================================
echo  Бэлэн боллоо! Хэдэн секундийн дараа http://localhost:3000 нээгдэнэ.
echo.
echo  Жишээ бүртгэлүүд:
echo    Админ:       admin@example.com     / ChangeMe123!
echo    Нийлүүлэгч:  creator@example.com   / password123
echo    Хэрэглэгч:   user@example.com      / password123
echo.
echo  Алхам алхмаар туршихыг хүсвэл TESTING.md файлыг нээж үзнэ үү.
echo  Зогсоохын тулд энэ цонхыг хаана уу (эсвэл Ctrl+C дараад Y).
echo ======================================================================
echo.

start "" http://localhost:3000
call npm run dev

pause
